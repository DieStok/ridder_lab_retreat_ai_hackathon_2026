#!/usr/bin/env bash
# install.sh — skill pack for hackathon idea #3 (pptx → markdown summary).
set -euo pipefail
REPO_ROOT="$(pwd)"
SKILLS_DIR="${REPO_ROOT}/.agents/skills"
TMP="${TMPDIR:-/tmp}/idea3-install"
mkdir -p "${SKILLS_DIR}" "${TMP}"
echo "==> Installing into ${SKILLS_DIR}"

# ---- Anthropic pptx (via document-skills plugin) ----------------------
echo "==> Anthropic pptx skill (manual /plugin step inside Claude Code)"
cat <<'EOF'
  In a Claude Code session, run:
      /plugin marketplace add anthropics/skills
      /plugin install document-skills@anthropic-agent-skills
  This installs pptx, xlsx, docx, and pdf skills together.
EOF

# ---- academic-pptx-skill ----------------------------------------------
echo "==> academic-pptx-skill (Gabberflast)"
rm -rf "${TMP}/academic-pptx-skill"
git clone --depth 1 https://github.com/Gabberflast/academic-pptx-skill "${TMP}/academic-pptx-skill" || \
  echo "WARN: clone failed"
if [ -d "${TMP}/academic-pptx-skill" ]; then
  cp -r "${TMP}/academic-pptx-skill" "${SKILLS_DIR}/academic-pptx"
  echo "  installed academic-pptx"
fi

# ---- pptx vision CLAUDE.md (ships with this pack) ---------------------
if [ -f "$(dirname "$0")/pptx_vision_CLAUDE.md" ]; then
  echo "==> pptx_vision_CLAUDE.md available"
  echo "  Copy → your project root for slide-image vision support."
fi

# ---- symlink ----------------------------------------------------------
if [ ! -e "${REPO_ROOT}/.claude/skills" ]; then
  mkdir -p "${REPO_ROOT}/.claude"
  ln -s ../.agents/skills "${REPO_ROOT}/.claude/skills"
  echo "==> Symlinked .claude/skills -> .agents/skills"
fi

echo
echo "==> Done. Installed under ${SKILLS_DIR}:"
ls -1 "${SKILLS_DIR}" 2>/dev/null
