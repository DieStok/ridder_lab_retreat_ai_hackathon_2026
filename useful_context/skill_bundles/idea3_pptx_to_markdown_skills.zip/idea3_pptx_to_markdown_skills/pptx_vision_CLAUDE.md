# CLAUDE.md — pptx-to-markdown vision pipeline

Tells Claude how to summarize a `.pptx` into Markdown, combining text
extraction with slide-image vision so figures and charts get read instead
of skipped.

---

## Pipeline (4 steps, in order)

### 1. Text + speaker-notes extraction

Use `python-pptx` (or the Anthropic `pptx` skill, which wraps it):

```python
from pptx import Presentation
prs = Presentation("input.pptx")
for slide in prs.slides:
    for shape in slide.shapes:
        if shape.has_text_frame:
            yield shape.text_frame.text
    if slide.has_notes_slide:
        yield slide.notes_slide.notes_text_frame.text
```

**Speaker notes are usually where the real content lives.** Lab-meeting
slides have one-line titles, paragraph-long notes. Weight notes ≥ slide text.

### 2. Slide → PNG rasterization

`python-pptx` won't render charts. Convert each slide to a PNG so Claude can
read them with vision:

```bash
soffice --headless --convert-to pdf input.pptx
pdftoppm -png -r 150 input.pdf slide  # produces slide-1.png, slide-2.png, ...
```

(LibreOffice is the most reliable converter. Fall back to `unoconv` if
`soffice` is unavailable; use `pdf2image` from Python if shelling out is
inconvenient.)

### 3. Per-slide vision pass

For each slide PNG, ask Claude (with vision) to describe:

- What chart / figure / diagram is shown (one sentence).
- What the chart's main finding is, if it's a results figure.
- Any axis labels, units, sample sizes, or stats called out on the slide.
- Any author / paper citation visible in the slide footer.

Don't ask Claude to OCR the bullet text from the slide image — that's already
extracted in step 1. Vision is *only* for figures.

### 4. Reference resolution

Collect every `(Author, Year)` and DOI / arXiv ID that appears in the slide
text or speaker notes. Hand this list to `paper-lookup` (already in the lab
repo). For each hit, fetch the abstract and write a one-sentence summary.

### 5. Compose the Markdown

Final output structure:

```markdown
# {{deck title}}
**Speaker:** {{guess from filename or first slide footer}}
**Date:** {{file mtime}}
**Slides:** {{n}}

## TL;DR
{{3-5 sentence summary of the whole deck}}

## Topic onboarding
{{1,000-word context for someone outside the SIG; defer to literature-review skill}}

## Slide-by-slide notes

### Slide 1 — {{action title}}
- Body: {{slide text + notes, paraphrased}}
- Figure: {{vision-pass description if present}}
- Cited: {{any references on this slide}}

### Slide 2 — {{action title}}
...

## References ({{N}})
1. Author1 et al., {{year}}. Title. *Venue*. [DOI]({{doi}}). — {{one-sentence summary from paper-lookup}}
2. ...

## Open questions / things the speaker glossed
{{Items where the slide had a chart but the notes didn't explain it, or where a citation appeared but couldn't be resolved.}}
```

The "open questions" section is the high-value part for SIG newsletters
(idea #5) — surface what the speaker *didn't* say.

## Don't

- **Don't** OCR images that already have a text twin (that's how you get
  duplicates).
- **Don't** include the entire vision-pass description verbatim. Distill.
- **Don't** invent citations; if `paper-lookup` returns nothing for a
  `(Author, Year)`, list it as "unresolved" rather than guessing the DOI.
- **Don't** send pre-publication unpublished slide content to a cloud LLM
  if the lab IP policy says so. The same caveat as ideas #2 and #4 — see
  idea #4's CLAUDE.md for the local-LLM routing pattern.
