# `idea3_pptx_to_markdown_skills/` — PowerPoint → Markdown summary bot

For idea **#3**: upload a `.pptx` (lab meeting / SIG slides), get a markdown
summary back. Could be slide-text-only, or augmented with vision-LLM analysis
of figures, references with abstracts, and a 1,000-word topic-onboarding
section.

## Already in the hackathon repo (don't reinstall)

- `paper-lookup` (K-Dense) — for citation / DOI lookups.
- `literature-review` — for the topic-onboarding 1,000-word context.
- `scientific-writing` — to format the markdown output cleanly.
- `slack-bolt-app` — for the upload-via-Slack ingress.

## Skills in this pack

| # | Skill | Source | Why |
|---|-------|--------|-----|
| 1 | Anthropic `pptx` (built-in) | `anthropics/skills` (`document-skills` plugin) | The official skill for reading and writing `.pptx`. Handles text extraction *and* OOXML manipulation, plus thumbnail-grid visual analysis. The foundation: install via `/plugin install document-skills@anthropic-agent-skills`. Available pre-installed on Claude.ai paid plans. |
| 2 | `academic-pptx-skill` | `Gabberflast/academic-pptx-skill` | Layered on top of Anthropic's `pptx`. Enforces academic conventions: action-titles ("X causes Y" not "Section 3"), citation discipline, exhibit-per-slide, ghost-deck test. Designed for conference talks / lab meetings — the right voice for parsing *back out* of an academic deck too, since it knows what to extract. |
| 3 | `pptx-toolkit` (mcpmarket) | mcpmarket | Reference SKILL.md if you want to roll your own pptx pipeline rather than using Anthropic's. Documents `python-pptx` patterns + html2pptx + thumbnail-based visual analysis. Useful as a how-to, not a dependency. |
| 4 | `pptx_vision_CLAUDE.md` (template, in this pack) | n/a | A short CLAUDE.md template that tells the agent how to: (a) extract slide text + speaker notes with `python-pptx`, (b) render each slide to PNG and feed it through Claude's native vision capability for figures/charts, (c) extract bibliographic entries → hand off to `paper-lookup`, (d) emit the final markdown. |

## Recommended bundle

Anthropic's `pptx` skill (do the heavy lifting) + `academic-pptx-skill`
(give the agent the right academic instinct for action titles, citations,
etc.) + the `pptx_vision_CLAUDE.md` template (wire vision into the loop) +
`paper-lookup` (already in the repo, hits arXiv / PubMed for DOI enrichment).

That's 3 new skills + 1 template + 1 repo skill — small enough to install in
the first 5 minutes of the hackathon.

## Caveats

- `python-pptx` doesn't render charts well — for chart-heavy decks, the
  vision approach (slide → PNG → Claude vision) is more reliable than text
  extraction. The CLAUDE.md template covers both paths.
- LibreOffice (`soffice --headless --convert-to png`) is the easiest way to
  rasterize slides. Fall back to `pdf2image` if you've already converted to
  PDF.
- The 1,000-word topic onboarding is the place to use `literature-review`
  from the K-Dense skills — that skill already handles "synthesize current
  knowledge on a topic" with citation discipline.
- Speaker notes are often where the real content lives (one-line slide titles,
  paragraph-long notes). Extract them and weight them at least equal to slide
  text in the summary.
