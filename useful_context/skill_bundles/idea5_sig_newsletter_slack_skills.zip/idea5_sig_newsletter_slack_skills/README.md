# `idea5_sig_newsletter_slack_skills/` — Lab-wide SIG newsletter to Slack

For idea **#5**: each SIG (Special Interest Group) generates a weekly /
biweekly Slack post — based on a meeting recording (transcript) or slides
or both — so busy lab members can keep up with sibling SIGs without
attending every meeting. Has overlap with ideas #2 (transcription) and
#3 (pptx → markdown).

## Already in the hackathon repo (don't reinstall)

- `slack-bolt-app` — the Slack-posting bolt (the most important piece — already there).
- `paper-lookup`, `literature-review`, `scientific-writing` (K-Dense).
- `compound-engineering` — has `ce-frontend-design` for any HTML newsletter view.

## Skills in this pack

| # | Skill | Source | Why |
|---|-------|--------|-----|
| 1 | `buzz` | Quickchat AI blog | A `/buzz` skill that watches a coding session and posts noteworthy moments to Slack with an AI-generated image. The exact pattern idea #5 needs: schedule it, give it a SIG-meeting transcript or slide deck, get a Slack post out. The reference implementation in the Quickchat post is fully spelled out (Slack bot scopes, Python script, SKILL.md with `PreToolUse` hook). |
| 2 | `internal-comms` (anthropic example-skills) | `anthropics/skills` | Anthropic-shipped example skill that drafts internal company-style updates with the right voice (concise, action-oriented, lists action items + decisions). Useful as the SIG-summary writer's voice template. |
| 3 | `slack-gif-creator` (anthropic example-skills) | `anthropics/skills` | Reaction-GIF / image generator for Slack. Optional but nice — gives the newsletter a recognizable visual signature so people stop scrolling past it. |
| 4 | `meeting-insights-analyzer` | `ComposioHQ/awesome-claude-skills` | Cross-meeting pattern analysis (already listed in idea #2). For idea #5, useful as the "remember what we covered last week" layer that gives continuity to the newsletter. |
| 5 | `mello` (n8n template, reference only) | `n8n.io workflows/5846` | Slack bolt + Claude that summarizes a channel's unread messages on demand. Reference architecture for the "summarize what was discussed" angle if you want a *manual* trigger as well as the scheduled one. |
| 6 | `sig_newsletter_CLAUDE.md` (template, in this pack) | n/a | The orchestration crib: how to chain transcript (idea #2) → pptx-summary (idea #3) → SIG post template → `slack-bolt-app` post → image attachment. |

## Recommended bundle

`buzz` (the scheduled Slack-posting pattern) + `internal-comms` (the voice
template) + the `sig_newsletter_CLAUDE.md` orchestrator + the existing
`slack-bolt-app` from the repo. Optionally add `slack-gif-creator` if you
want the newsletter to have an image header. Skip `meeting-insights-analyzer`
unless you're explicitly building the cross-meeting continuity layer.

## Caveats

- The `buzz` skill is for a *coding session*. Repurposing it for a SIG
  meeting means: (a) run it on a transcript file, not a live session,
  (b) trigger it on cron (`0 9 * * MON`) instead of in-session hooks. The
  Python script + skill structure transfer; the trigger doesn't.
- Slack bot tokens have channel-level scope. The `slack-bolt-app` already
  in the repo handles auth — don't reinvent it. Add the SIG channels to
  its allowlist.
- The brainstorm doc emphasizes that SIGs are siloed and busy postdocs
  miss months of work. Optimize for **scannability**: the post should fit
  one phone screen. Use `internal-comms`'s "TL;DR + 3 bullets + link to
  full notes" pattern, not a wall of text.
- Privacy: if a SIG meeting discusses unpublished results, route through
  the **local-LLM** stack from idea #4. The Slack post itself is
  presumably internal-only; just don't have a cloud LLM in the summary loop.
