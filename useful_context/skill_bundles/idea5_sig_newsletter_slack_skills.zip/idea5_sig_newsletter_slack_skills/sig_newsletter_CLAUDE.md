# CLAUDE.md — SIG-newsletter orchestrator

Tells Claude how to chain the three previous ideas (transcript → pptx →
Slack post) into a single weekly SIG-newsletter pipeline.

---

## Pipeline

1. **Input**: a SIG meeting recording (audio or video) and/or a `.pptx`
   from the meeting.
2. **Transcribe** (idea #2 stack): `transcript-critic` for short meetings,
   VibeVoice-ASR-HF for ≥30 min meetings with multiple speakers. Output:
   `transcripts/<sig>-<ISO-date>.md`.
3. **Parse slides** (idea #3 stack): Anthropic `pptx` + `academic-pptx-skill`
   + `pptx_vision_CLAUDE.md`. Output: `slide-summaries/<sig>-<ISO-date>.md`.
4. **Compose the newsletter** using the `internal-comms` skill's voice and
   the template below.
5. **Post to Slack** with `slack-bolt-app` to a `#sig-<name>-newsletter`
   channel. Add a header image with `slack-gif-creator` if you want.
6. **Archive** the full notes (transcript + slide summary) to a
   permanent location (Obsidian vault, lab wiki, GitHub repo). The Slack
   post links to the archive.

## Slack post template (target: fits one phone screen)

```
*<SIG-name> · <ISO-date> · <speaker name>*

📌 *TL;DR* — <one sentence, the single most important takeaway>

🔑 *3 things you need to know*
1. <bullet, ≤ 20 words>
2. <bullet, ≤ 20 words>
3. <bullet, ≤ 20 words>

🚨 *Decisions made*
- <none, OR list, max 3>

🛠 *Action items*
- <name>: <action>, by <date>
- <name>: <action>, by <date>

📚 *5 must-read* (from idea #1's pipeline + paper-lookup)
1. <Author et al, year, one-liner — DOI link>
2. ...

🔗 *Full notes:* <link>
🎤 *Recording:* <link, if shareable>
```

## Voice rules (deferred to `internal-comms`)

- TL;DR is one sentence. Not two. Not "we discussed X and Y" — pick the
  single sharpest finding.
- Bullets are facts and decisions, not feelings ("we felt this was important").
- If a SIG meeting was a brainstorm with no decisions, say so explicitly:
  "🚨 No decisions; brainstorm session. See full notes for the discussion thread."
- Never list participants by name unless they took an action item.

## When the SIG meeting was about unpublished results

Route the transcription + summary through the local-LLM stack (idea #4's
`local_llm_routing_CLAUDE.md`). The Slack post stays internal — that's fine
— but the LLM that *writes* the post shouldn't see the unpublished material
unless it's running on the HPC.

## Cross-meeting continuity (optional, advanced)

If `meeting-insights-analyzer` is installed and you have ≥4 weeks of
transcripts, add a "🪜 Continuity" section that references which open
questions from prior meetings the speaker addressed (or didn't). This is
the high-value differentiator over a manual newsletter, but it's also
the part that needs a body of historical data to be useful.

## Failure modes to handle

- **Empty meeting** (no slides, sparse transcript): post a minimal
  "🤷 Light week — no notable updates from <SIG>" instead of padding.
- **All slides, no transcript**: skip step 2; trust the slide summary.
- **All transcript, no slides**: skip step 3; transcript carries the post.
- **Speaker explicitly says "off the record"**: redact that span before
  writing the summary. The transcript skill should support a `[REDACTED]`
  marker workflow.

## Cadence + scheduling

```cron
# weekly Monday 09:00 — re-run last week's SIG meetings
0 9 * * MON  cd /lab/sig-newsletter && claude -p "$(cat CLAUDE.md && echo 'process all transcripts in transcripts/ from the past 7 days')"
```

(Or use the `buzz` skill's hook pattern if you want to fire on
transcript-folder-write rather than cron.)
