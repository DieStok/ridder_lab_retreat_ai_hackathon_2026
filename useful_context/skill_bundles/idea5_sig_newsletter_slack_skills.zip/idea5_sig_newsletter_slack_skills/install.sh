#!/usr/bin/env bash
# install.sh — skill pack for hackathon idea #5 (SIG newsletter Slack).
set -euo pipefail
REPO_ROOT="$(pwd)"
SKILLS_DIR="${REPO_ROOT}/.agents/skills"
TMP="${TMPDIR:-/tmp}/idea5-install"
mkdir -p "${SKILLS_DIR}" "${TMP}"
echo "==> Installing into ${SKILLS_DIR}"

# ---- Anthropic internal-comms + slack-gif-creator (example-skills) ----
echo "==> Anthropic internal-comms + slack-gif-creator (manual /plugin step)"
cat <<'EOF'
  In a Claude Code session, run:
      /plugin marketplace add anthropics/skills
      /plugin install example-skills@anthropic-agent-skills
  This installs internal-comms (voice template) and slack-gif-creator,
  alongside theme-factory, web-artifacts-builder, webapp-testing, and
  other example skills.
EOF

# ---- buzz skill (Quickchat AI blog reference; manual reconstruction) -
echo "==> buzz skill (Quickchat AI reference)"
cat <<'EOF'
  The buzz skill is described in full at:
      https://quickchat.ai/post/claude-code-skill-watches-coding-sessions-shares-to-slack
  It includes:
    - SKILL.md with YAML frontmatter (allowed-tools: Bash, PreToolUse hook)
    - .claude/hooks/validate-buzz-commands.sh (bash allowlist)
    - post_buzz.py (Slack file_upload + AI image gen)
    - Slack app setup (chat:write, files:write scopes)
  Re-implement at ${SKILLS_DIR}/buzz/. The post has copy-pasteable code.
  For idea #5, replace the "watch the coding session" trigger with
  a cron trigger on transcripts/<date>.md from idea #2.
EOF

# ---- meeting-insights-analyzer (ComposioHQ) - if not already from idea2 -
if [ ! -d "${SKILLS_DIR}/meeting-insights-analyzer" ]; then
  echo "==> meeting-insights-analyzer (ComposioHQ)"
  rm -rf "${TMP}/awesome-claude-skills"
  git clone --depth 1 https://github.com/ComposioHQ/awesome-claude-skills "${TMP}/awesome-claude-skills" || \
    echo "WARN: clone failed"
  if [ -d "${TMP}/awesome-claude-skills/meeting-insights-analyzer" ]; then
    cp -r "${TMP}/awesome-claude-skills/meeting-insights-analyzer" "${SKILLS_DIR}/"
    echo "  installed meeting-insights-analyzer"
  fi
fi

# ---- SIG newsletter orchestrator CLAUDE.md ---------------------------
if [ -f "$(dirname "$0")/sig_newsletter_CLAUDE.md" ]; then
  echo "==> sig_newsletter_CLAUDE.md available"
  echo "  Copy → your project root for the orchestrator template."
fi

# ---- symlink ----------------------------------------------------------
if [ ! -e "${REPO_ROOT}/.claude/skills" ]; then
  mkdir -p "${REPO_ROOT}/.claude"
  ln -s ../.agents/skills "${REPO_ROOT}/.claude/skills"
  echo "==> Symlinked .claude/skills -> .agents/skills"
fi

echo
echo "==> Done. Installed under ${SKILLS_DIR}:"
ls -1 "${SKILLS_DIR}" 2>/dev/null
