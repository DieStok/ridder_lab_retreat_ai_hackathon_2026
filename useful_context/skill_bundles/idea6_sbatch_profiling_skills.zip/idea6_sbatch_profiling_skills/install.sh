#!/usr/bin/env bash
# install.sh — skill pack for hackathon idea #6 (sbatch profiling).
set -euo pipefail
REPO_ROOT="$(pwd)"
SKILLS_DIR="${REPO_ROOT}/.agents/skills"
TMP="${TMPDIR:-/tmp}/idea6-install"
mkdir -p "${SKILLS_DIR}" "${TMP}"
echo "==> Installing into ${SKILLS_DIR}"

# ---- maxtext-slurm skills subset (the analysis logic) -----------------
echo "==> AMD-AGI/maxtext-slurm (skills subset)"
rm -rf "${TMP}/maxtext-slurm"
git clone --depth 1 https://github.com/AMD-AGI/maxtext-slurm "${TMP}/maxtext-slurm" || \
  echo "WARN: clone failed"
if [ -d "${TMP}/maxtext-slurm/skills" ]; then
  for s in "${TMP}/maxtext-slurm/skills"/*/; do
    name="$(basename "$s")"
    cp -r "$s" "${SKILLS_DIR}/maxtext-${name}"
    echo "  installed maxtext-${name}"
  done
fi

# ---- brunoasm phylogenomic-slurm reference ----------------------------
echo "==> brunoasm/my_claude_skills (phylogenomic SLURM reference)"
rm -rf "${TMP}/brunoasm"
git clone --depth 1 https://github.com/brunoasm/my_claude_skills "${TMP}/brunoasm" || \
  echo "WARN: clone failed"
# Just copy SLURM-related skills, not the whole repo
if [ -d "${TMP}/brunoasm" ]; then
  cp -r "${TMP}/brunoasm" "${SKILLS_DIR}/brunoasm-phylogenomic"
  echo "  copied brunoasm-phylogenomic — review and trim to the SLURM bits."
fi

# ---- mcpmarket skills (manual fetch — they're behind a viewer) -------
echo "==> SLURM Workflow Integration (mcpmarket)"
echo "  No git URL — fetch the SKILL.md manually from"
echo "    https://mcpmarket.com/tools/skills/slurm-workflow-integration"
echo "  and put it in ${SKILLS_DIR}/slurm-workflow-integration/SKILL.md"

echo "==> SLURM GPU Cluster Management (lobehub)"
echo "  Fetch from https://lobehub.com/skills/serendipityoneinc-srp-claude-code-marketplace-slurm"
echo "  via:"
echo "      curl https://lobehub.com/skills/serendipityoneinc-srp-claude-code-marketplace-slurm/skill.md"
echo "  and put it in ${SKILLS_DIR}/srp-slurm/SKILL.md"

# ---- jobstats orchestrator CLAUDE.md ---------------------------------
if [ -f "$(dirname "$0")/jobstats_CLAUDE.md" ]; then
  echo "==> jobstats_CLAUDE.md available"
  echo "  Copy → your project root for the weekly-report orchestrator."
fi

# ---- symlink ----------------------------------------------------------
if [ ! -e "${REPO_ROOT}/.claude/skills" ]; then
  mkdir -p "${REPO_ROOT}/.claude"
  ln -s ../.agents/skills "${REPO_ROOT}/.claude/skills"
  echo "==> Symlinked .claude/skills -> .agents/skills"
fi

echo
echo "==> Done. Installed under ${SKILLS_DIR}:"
ls -1 "${SKILLS_DIR}" 2>/dev/null
