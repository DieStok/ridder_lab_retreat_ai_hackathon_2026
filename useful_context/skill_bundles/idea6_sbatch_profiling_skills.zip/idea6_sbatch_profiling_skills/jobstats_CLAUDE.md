# CLAUDE.md — Weekly sbatch profiling report

Tells Claude how to generate the weekly per-user SLURM-usage report that
idea #6 calls for. Designed to work *without* Princeton `jobstats` (which
needs HPC-admin install) — `sacct` + `reportseff` give 80% of the value.

---

## Ingredients

- `sacct` — built-in to SLURM, no install needed. Pulls historical job
  records.
- `reportseff` — `pip install reportseff`. Wrapper around `sacct` with
  cleaner output and per-job efficiency scoring. Works without admin help.
- `seff <jobid>` — single-job summary, also built-in.
- (Optional, when admins enable it) Princeton `jobstats` for time-series
  per-job CPU / GPU / memory plots.

## Pipeline

### Step 1 — pull last week's jobs for one user

```bash
sacct -u "$USER" \
  --starttime $(date -d "7 days ago" +%Y-%m-%dT00:00:00) \
  --endtime now \
  --format=JobID,JobName,Partition,State,Elapsed,Timelimit,ReqMem,MaxRSS,ReqCPUS,AllocCPUS,CPUTime,TotalCPU,ReqTRES,AllocTRES \
  --parsable2 --noheader \
  --units=G > /tmp/jobs.psv
```

### Step 2 — efficiency score per job

```bash
reportseff --since 7days --user "$USER" --format JobID,State,CPUEff,MemEff,TimeEff,Memory,Elapsed
```

For each job, compute three flags:

| Flag                     | Trigger                                            |
| ------------------------ | -------------------------------------------------- |
| **Mem overprovisioned**  | `MaxRSS < 0.25 * ReqMem` AND `ReqMem > 4G`         |
| **CPU underused**        | `TotalCPU/CPUTime < 0.30` (CPUEff < 30%)           |
| **Time overprovisioned** | `Elapsed < 0.20 * Timelimit` AND `Timelimit > 1h`  |
| **Failed**               | `State` in {`FAILED`, `OUT_OF_MEMORY`, `TIMEOUT`}  |

(Tune thresholds after one week of real data; these are starting points.)

### Step 3 — per-user weekly markdown

Format:

```markdown
# SLURM weekly report — {{user}}, week of {{ISO-week}}

**Jobs run:** {{n}}  |  **Successful:** {{n_ok}}  |  **Failed:** {{n_fail}}
**CPU-hours used:** {{cpu_h}}  |  **CPU-hours allocated:** {{alloc_h}}  ({{efficiency}}% efficient)

## What's working
- {{Mention the most efficient job: "Job 12345 used 92% of allocated memory at peak — well-sized."}}

## What to change next week

### 1. Memory overprovisioning ({{n}} jobs)
- Job {{id}} ({{name}}): requested {{ReqMem}} GB, peaked at {{MaxRSS}} GB. Try `--mem={{suggested}}G` next time.
- Job {{id}}: requested 64 GB, peaked at 3.2 GB. Try `--mem=8G`.

### 2. CPU underuse ({{n}} jobs)
- Job {{id}} ({{name}}): allocated {{n_cpus}} cores, used {{eff}}% on average. Either drop to `--cpus-per-task=1` or parallelize the workload (joblib, GNU parallel, …).

### 3. Time overprovisioning ({{n}} jobs)
- Job {{id}}: allocated {{Timelimit}}, finished in {{Elapsed}}. `--time={{suggested}}` would have queued faster.

### 4. Failures ({{n}} jobs)
- Job {{id}} ({{name}}): {{State}}, last log line: "{{tail of .err file}}". Likely cause: {{best guess}}.

## How to apply this
The single change with the biggest queue-time impact is usually fixing
the memory request. Pick one job type, edit one line in your sbatch
template, and check next week's report.
```

### Step 4 — deliver

- Slack DM (private channel) via `slack-bolt-app` from the repo. The
  brainstorm doc is right that this should be a nudge, not a public shame
  board — start with DMs.
- Optionally archive at `reports/<user>/<ISO-week>.md` so the user can
  refer back.

## Lab-wide weekly aggregation (optional)

If the lab wants a roll-up for everyone:

```bash
sacct -a --starttime ... --format=User,JobID,...
```

(`-a` shows all users — needs cluster permission.) Feed into a single
"this week's biggest overprovisioner: {{user}} requested {{X}} CPU-hours
they didn't need" leaderboard. **Run by consent only** — if anyone opts
out, exclude their jobs from the aggregate.

## What `jobstats` adds (when admins enable it)

Once the cluster runs Prometheus + Grafana with `jobstats`, you get:

- Time-series plots of CPU / GPU / memory per job (not just peak).
- Per-job email reports on `--mail-type=END`.
- The `mydella.princeton.edu/pun/sys/jobstats/<jobid>` style web UI.

When that lands, replace the `sacct` step with a `jobstats <jobid>` call —
the output is already structured for this kind of summary.

## Don't

- Don't re-flag the same overprovisioned job week after week if the user
  hasn't fixed it. Keep a `~/.cache/sbatch-report/dismissed.json`.
- Don't run this on the cluster head node. Run it as its own small `sbatch`
  on a low-priority node, or on a laptop with `ssh hpc sacct ...`.
- Don't blame failures whose cause is upstream (cluster outage, FS issue).
  Tag those as "infra" so the user knows it wasn't them.
