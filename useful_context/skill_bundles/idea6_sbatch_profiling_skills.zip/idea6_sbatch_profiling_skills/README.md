# `idea6_sbatch_profiling_skills/` — Automated sbatch/srun profiling + reporting

For idea **#6**: profile lab members' SLURM jobs automatically and surface
a daily/weekly report on overprovisioning, underuse, and (potentially) job
failures. The brainstorm doc names Princeton's
[`jobstats`](https://github.com/PrincetonUniversity/jobstats) as the
backend tool — that needs HPC-admin install — and asks what workflow could
*automate* the optimization step on top.

## Already in the hackathon repo (don't reinstall)

- `hpc-cluster` (lab-internal, in `/mnt/skills/user/hpc-cluster/`) — the lab's
  own SLURM cheat sheet for the UMC Utrecht cluster (hpcs05/hpcs06).
- `slack-bolt-app` — for delivery of the weekly report.
- `compound-engineering` — `ce-frontend-design` for the dashboard.

## Skills in this pack

| # | Skill | Source | Why |
|---|-------|--------|-----|
| 1 | `slurm-workflow-integration` | mcpmarket | The most general SLURM skill: auto-detection of env vars + GPU + Conda, multi-step batch with cycles/dry-run, standardized resource templates. Good baseline for "submit a job" workflows; you'll layer the *profiling* logic on top. |
| 2 | `serendipityoneinc-srp-claude-code-marketplace-slurm` | lobehub | A more opinionated SLURM skill targeting GPU clusters (H100/H200), Apptainer containers, and the `ssubmit` wrapper pattern. Useful as a reference for the GPU partition workflow even if your lab uses different partitions. |
| 3 | `maxtext-slurm` (skills subset) | `AMD-AGI/maxtext-slurm` | Toolkit with a `skills/` directory containing **performance analysis**, **job failure triage**, and **TSDB-based incident diagnosis** skills. Encodes "interpret these results, distinguish symptoms from root causes, trace causal chains" — exactly the analysis layer idea #6 needs. The most directly applicable existing skill for the *reporting* angle. |
| 4 | `phylogenomic-slurm` (subset of `brunoasm/my_claude_skills`) | `brunoasm/my_claude_skills` | Bioinformatics-specific SLURM patterns from a working lab — the closest cousin to the de Ridder lab use case in the public ecosystem. Useful as a sanity check for the kinds of jobs lab members actually submit. |
| 5 | `jobstats_CLAUDE.md` (template, in this pack) | n/a | A CLAUDE.md template that tells Claude how to: (a) parse `sacct -j <jobid> --format=JobID,JobName,Partition,Elapsed,MaxRSS,ReqMem,NCPUS,CPUTime,State -P`, (b) compare to the requested resources, (c) emit a per-user weekly markdown report with overprovisioning flags, (d) post to the lab Slack via `slack-bolt-app`. The brainstorm doc explicitly asks for a workflow on top of `jobstats` — this is that workflow. |

## Recommended bundle

`maxtext-slurm` skills (the analysis logic) + the `jobstats_CLAUDE.md`
orchestrator + `slack-bolt-app` from the repo (the delivery layer).
`slurm-workflow-integration` is optional — it's about *submitting* jobs,
which the lab already does manually, not about analyzing them.

## Caveats

- **Princeton `jobstats` needs HPC-admin install.** Roy / the cluster team
  has to set it up — it depends on Prometheus + Grafana for the time-series
  metrics. The brainstorm doc flags this. In the meantime, `sacct` +
  `reportseff` give you 80% of the value with no admin involvement.
- The lab's `hpc-cluster` skill (already in the repo) has the actual SLURM
  syntax for hpcs05/hpcs06. Read that first; the public skills above are for
  the *workflow patterns*, not the cluster-specific commands.
- **Don't run this report job on a head node.** The brainstorm doc's
  security note applies: anything that pulls public data + writes to Slack
  is fine on a laptop, but reporting on cluster usage should run as a
  small `sbatch` itself, on a low-priority node.
- The hard part of idea #6 isn't the metrics — it's *changing user
  behavior*. The report needs to nudge, not nag. Consider: weekly Slack DM
  with one suggestion ("you allocated 64 GB for 14 jobs that peaked at 4 GB
  — try `--mem=8G`"), not a public shame board.
