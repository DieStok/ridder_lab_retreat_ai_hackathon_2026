# CLAUDE.md — VibeVoice-ASR-HF transcription crib

The brainstorm doc (idea #2) names Microsoft VibeVoice-ASR-HF as a candidate
for realtime ≤60-min transcription with speaker attribution. There's no
Claude skill for it yet. This CLAUDE.md tells the agent how to use it.

---

## Model

- **Repo**: https://github.com/microsoft/VibeVoice
- **HF model**: https://huggingface.co/microsoft/VibeVoice-ASR-HF
- **Docs**: https://github.com/microsoft/VibeVoice/blob/main/docs/vibevoice-asr.md
- **Capability**: realtime ASR on up to 60 min of audio, including speaker
  detection and attribution.
- **Runtime**: HuggingFace `transformers` library; needs a GPU for realtime.

## When to use VibeVoice instead of whisper.cpp / Whisper

| Use VibeVoice when…                                  | Use Whisper / whisper.cpp when…       |
| ---------------------------------------------------- | ------------------------------------- |
| You need speaker diarization out of the box          | Single-speaker audio                  |
| Meeting is ≥30 min and < 60 min                      | Quick voice memos, podcasts           |
| GPU is available (HPC node, decent local GPU)        | CPU-only / laptop                     |
| You want one model for ASR + diarization             | You're fine running pyannote separately |
| The audio has multiple back-to-back speakers         | One person dictating                  |

## Minimal Python pipeline

```python
import torch
from transformers import AutoProcessor, AutoModelForSpeechSeq2Seq

device = "cuda" if torch.cuda.is_available() else "cpu"
model_id = "microsoft/VibeVoice-ASR-HF"

processor = AutoProcessor.from_pretrained(model_id)
model = AutoModelForSpeechSeq2Seq.from_pretrained(
    model_id, torch_dtype=torch.float16, device_map=device,
)

# audio is a 16 kHz mono numpy array or a path read with librosa/torchaudio
inputs = processor(audio, sampling_rate=16000, return_tensors="pt").to(device)
with torch.inference_mode():
    out = model.generate(**inputs, max_new_tokens=4096)
text = processor.batch_decode(out, skip_special_tokens=True)[0]
print(text)  # contains speaker tags inline
```

(Always verify against the live docs at the link above — the API may have
shifted since this template was written.)

## Where to run

- **HPC GPU node** for batch jobs (post-meeting transcription).
  ```bash
  #SBATCH --partition=gpu
  #SBATCH --gres=gpu:1
  #SBATCH --time=01:00:00
  #SBATCH --mem=32G
  ```
- **Local laptop GPU** only if you have ≥16 GB VRAM and a meeting < 30 min.
- **Don't use the cloud** if the meeting content is IP-sensitive — VibeVoice
  is open-weight, so HPC-local is the right call.

## Output post-processing

VibeVoice produces speaker-labeled text. Hand this off to the
`meeting-insights-analyzer` skill (or to Claude with the K-Dense
`literature-review` skill loaded) for the cross-meeting / paper-citation
enrichment step. Recommend writing the raw transcript to
`transcripts/{{ISO-date}}-{{slug}}.md` so subsequent agents can find it.

## Privacy note

If you batch-transcribe lab meetings, **do not** push transcripts to
cloud-hosted Claude with the meeting content embedded in the message body.
Either:

1. Run the entire pipeline (VibeVoice + summary LLM) on the HPC with a local
   model (Ollama / vllm-mlx / llama.cpp — see idea #4 for details), or
2. Redact named individuals before sending to a cloud LLM.

This is the same privacy posture as idea #4 (local IP-safe review).
