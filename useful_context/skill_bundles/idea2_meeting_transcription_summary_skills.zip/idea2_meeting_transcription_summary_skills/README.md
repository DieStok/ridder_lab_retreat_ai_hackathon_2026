# `idea2_meeting_transcription_summary_skills/` — Meeting transcription & enrichment

For idea **#2**: automatically record + transcribe meetings, then run an LLM
over the transcript for fact-checking, cross-referencing earlier meetings,
adversarial review of brainstorm ideas, must-read paper suggestions, etc.
The brainstorm doc explicitly names Microsoft VibeVoice-ASR-HF (60-min
realtime transcription with speaker attribution) — keep that in mind.

## Already in the hackathon repo (don't reinstall)

- `paper-lookup`, `literature-review`, `scientific-writing` (K-Dense) — for
  the cross-referencing step.
- `slack-bolt-app` — for delivering the summary.
- `compound-engineering` — `ce-frontend-design` and friends, useful for any
  HTML report at the end.

## Skills in this pack

| # | Skill | Source | Why |
|---|-------|--------|-----|
| 1 | `transcript-critic` | `jftuga/transcript-critic` | The most operationally useful Claude Code skill for this idea. Runs `whisper.cpp` (local) on audio / video / YouTube URL, then runs a structured critical-analysis prompt that produces timestamped summaries, evidence notes, logical-fallacy flags, and underdeveloped-area markers. Single `/transcribe` slash command does the whole pipeline. |
| 2 | `transcribe` (with diarization) | mcp.directory skill #1963 | Wraps OpenAI's `gpt-4o-transcribe-diarize` for speaker labels + known-speaker hints. Use this when local Whisper isn't enough and the meeting was *not* IP-sensitive. Auto-falls-back to `gpt-4o-mini-transcribe` for fast text-only runs. |
| 3 | `whisper` | skillsdirectory.com (`zechenzhangagi-whisper`) | A SKILL.md that documents Whisper installation, model size selection, GPU vs CPU performance, and best-practice flags (`--initial_prompt` for jargon, `--word_timestamps`). Useful as a reference when wiring Whisper into a custom pipeline rather than using `transcript-critic`'s opinionated approach. |
| 4 | `meeting-insights-analyzer` | `ComposioHQ/awesome-claude-skills` | Post-transcription analysis layer. Looks at *patterns across many meetings* — when you avoid conflict, dominate the conversation, miss listening cues, etc. Useful for the "compare to earlier meetings" enrichment angle. Runs on a folder of transcripts, not a single one. |
| 5 | `obsidian-meeting-transcriber` | mcpmarket | End-to-end pipeline: matches multi-track audio (e.g. Rodecaster) with screen recording, runs Whisper, and writes Obsidian-vault-friendly markdown notes. Useful as a reference if your lab uses Obsidian; can be cannibalized for any markdown output. |
| 6 | `vibevoice-asr-CLAUDE.md` (template, in this pack) | n/a | A short CLAUDE.md template that pins the agent to Microsoft's [VibeVoice-ASR-HF](https://github.com/microsoft/VibeVoice/blob/main/docs/vibevoice-asr.md) for realtime 60-min transcription with speaker attribution. The brainstorm doc names this model specifically; no Claude skill exists for it yet. |

## Recommended bundle

Privacy-first (lab default): `transcript-critic` (whisper.cpp, fully local) +
`meeting-insights-analyzer` for the cross-meeting layer + the
`vibevoice-asr-CLAUDE.md` template for ≥30 min meetings with speaker labels.
The lab Slack delivery comes from `slack-bolt-app` (already in the repo).

If a meeting is *not* IP-sensitive and quality matters more than privacy,
swap `transcript-critic` for `transcribe` with diarization.

## Caveats

- Bots in Microsoft Teams are *hard*. The brainstorm doc flags this. If your
  team picks idea #2, plan to record locally (Krisp, Loopback, Audacity,
  or just a phone) rather than fight the Teams bot framework in 50 minutes.
- VibeVoice-ASR-HF runs on Hugging Face Transformers — needs a decent GPU
  for realtime. The HPC has GPUs; route the audio there, don't run it on a
  laptop.
- Whisper hallucinates on long silences and music. `transcript-critic` uses
  whisper.cpp which inherits this. Set `--no_speech_threshold` higher or
  pre-trim silence with ffmpeg.
