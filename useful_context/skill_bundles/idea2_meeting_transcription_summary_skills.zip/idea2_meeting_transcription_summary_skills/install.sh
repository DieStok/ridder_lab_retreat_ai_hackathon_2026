#!/usr/bin/env bash
# install.sh — skill pack for hackathon idea #2 (meeting transcription/summary).
set -euo pipefail
REPO_ROOT="$(pwd)"
SKILLS_DIR="${REPO_ROOT}/.agents/skills"
TMP="${TMPDIR:-/tmp}/idea2-install"
mkdir -p "${SKILLS_DIR}" "${TMP}"
echo "==> Installing into ${SKILLS_DIR}"

# ---- transcript-critic (whisper.cpp + critical analysis prompt) -------
echo "==> transcript-critic (jftuga)"
rm -rf "${TMP}/transcript-critic"
git clone --depth 1 https://github.com/jftuga/transcript-critic "${TMP}/transcript-critic" || \
  echo "WARN: clone failed"
if [ -d "${TMP}/transcript-critic" ]; then
  mkdir -p "${SKILLS_DIR}/transcribe"
  cp "${TMP}/transcript-critic/SKILL.md" "${SKILLS_DIR}/transcribe/" 2>/dev/null || true
  cp "${TMP}/transcript-critic/transcribe.sh" "${SKILLS_DIR}/transcribe/" 2>/dev/null || true
  cp "${TMP}/transcript-critic/ANALYSIS_PROMPT.md" "${SKILLS_DIR}/transcribe/" 2>/dev/null || true
  echo "  installed transcribe (transcript-critic)"
  echo "  REMEMBER: install whisper.cpp + a ggml model first;"
  echo "            update PGM and MODEL paths in SKILL.md."
fi

# ---- transcribe with diarization (mcp.directory) ----------------------
echo "==> transcribe with diarization (mcp.directory)"
mkdir -p "${SKILLS_DIR}/transcribe-diarize"
cd "${SKILLS_DIR}/transcribe-diarize"
curl -fsSL "https://mcp.directory/api/skills/download/1963" -o skill.zip 2>/dev/null && \
  unzip -o skill.zip && rm skill.zip || \
  echo "WARN: mcp.directory download failed — fetch manually from https://fastmcp.me/skills/details/1963/transcribe"
cd "${REPO_ROOT}"

# ---- meeting-insights-analyzer (ComposioHQ) ---------------------------
echo "==> meeting-insights-analyzer (ComposioHQ)"
rm -rf "${TMP}/awesome-claude-skills"
git clone --depth 1 https://github.com/ComposioHQ/awesome-claude-skills "${TMP}/awesome-claude-skills" || \
  echo "WARN: clone failed"
if [ -d "${TMP}/awesome-claude-skills/meeting-insights-analyzer" ]; then
  cp -r "${TMP}/awesome-claude-skills/meeting-insights-analyzer" "${SKILLS_DIR}/"
  echo "  installed meeting-insights-analyzer"
fi

# ---- whisper reference skill (skillsdirectory) ------------------------
echo "==> whisper reference skill"
echo "  Browse https://www.skillsdirectory.com/skills/zechenzhangagi-whisper"
echo "  and copy its SKILL.md into ${SKILLS_DIR}/whisper/SKILL.md"
echo "  (single-file skill, no clone needed)"

# ---- vibevoice CLAUDE.md template -------------------------------------
if [ -f "$(dirname "$0")/vibevoice_asr_CLAUDE.md" ]; then
  echo "==> vibevoice-asr CLAUDE.md template available"
  echo "  Copy $(dirname "$0")/vibevoice_asr_CLAUDE.md → your project root"
  echo "  to use Microsoft's VibeVoice-ASR-HF for realtime transcription."
fi

# ---- symlink ----------------------------------------------------------
if [ ! -e "${REPO_ROOT}/.claude/skills" ]; then
  mkdir -p "${REPO_ROOT}/.claude"
  ln -s ../.agents/skills "${REPO_ROOT}/.claude/skills"
  echo "==> Symlinked .claude/skills -> .agents/skills"
fi

echo
echo "==> Done. Installed under ${SKILLS_DIR}:"
ls -1 "${SKILLS_DIR}" 2>/dev/null
