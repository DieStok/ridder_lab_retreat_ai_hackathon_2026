#!/usr/bin/env bash
# install.sh — skill pack for hackathon idea #4 (local IP-safe review).
set -euo pipefail
REPO_ROOT="$(pwd)"
SKILLS_DIR="${REPO_ROOT}/.agents/skills"
TMP="${TMPDIR:-/tmp}/idea4-install"
mkdir -p "${SKILLS_DIR}" "${TMP}"
echo "==> Installing into ${SKILLS_DIR}"

# ---- claesbackman AI-research-feedback (slash commands, curl install) -
echo "==> claesbackman/AI-research-feedback"
COMMANDS_DIR="${HOME}/.claude/commands"
mkdir -p "${COMMANDS_DIR}"
for cmd in review-paper review-paper-light review-paper-code review-pap review-grant; do
  curl -fsSL "https://raw.githubusercontent.com/claesbackman/AI-research-feedback/main/Skills/${cmd}.md" \
    -o "${COMMANDS_DIR}/${cmd}.md" 2>/dev/null && \
    echo "  installed /${cmd}" || \
    echo "  WARN: ${cmd} curl failed — fetch manually"
done
echo "  These are GLOBAL slash commands at ${COMMANDS_DIR}/, not project skills."

# ---- cc-review (any-LLM reviewer with Ollama private guardrail) -------
echo "==> cc-review (DEV.to / srinvias_mudavath)"
echo "  Repo: https://github.com/srinvias-mudavath/cc-review (verify exact URL)"
echo "  Manual install — read the DEV.to post for the bash + YAML setup,"
echo "  put the cc-review/ folder in ${SKILLS_DIR}/cc-review/."

# ---- uditgoenka/autoresearch ------------------------------------------
echo "==> uditgoenka/autoresearch (11-command port)"
rm -rf "${TMP}/autoresearch"
git clone --depth 1 https://github.com/uditgoenka/autoresearch "${TMP}/autoresearch" || \
  echo "WARN: clone failed"
if [ -d "${TMP}/autoresearch" ]; then
  cp -r "${TMP}/autoresearch" "${SKILLS_DIR}/autoresearch"
  echo "  installed autoresearch"
  echo "  Run install.sh inside ${SKILLS_DIR}/autoresearch to wire up the 11 commands."
fi

# ---- lcrawfurd paper-review skills ------------------------------------
echo "==> lcrawfurd/claude-skills"
rm -rf "${TMP}/lcrawfurd-claude-skills"
git clone --depth 1 https://github.com/lcrawfurd/claude-skills "${TMP}/lcrawfurd-claude-skills" || \
  echo "WARN: clone failed"
if [ -d "${TMP}/lcrawfurd-claude-skills" ]; then
  cp -r "${TMP}/lcrawfurd-claude-skills" "${SKILLS_DIR}/lcrawfurd-claude-skills"
  echo "  installed lcrawfurd-claude-skills"
fi

# ---- local LLM routing CLAUDE.md template -----------------------------
if [ -f "$(dirname "$0")/local_llm_routing_CLAUDE.md" ]; then
  echo "==> local_llm_routing_CLAUDE.md available"
  echo "  Copy → your project root for the local-LLM routing setup."
fi

# ---- symlink ----------------------------------------------------------
if [ ! -e "${REPO_ROOT}/.claude/skills" ]; then
  mkdir -p "${REPO_ROOT}/.claude"
  ln -s ../.agents/skills "${REPO_ROOT}/.claude/skills"
  echo "==> Symlinked .claude/skills -> .agents/skills"
fi

echo
echo "==> Done. Installed under ${SKILLS_DIR}:"
ls -1 "${SKILLS_DIR}" 2>/dev/null
echo
echo "==> Slash commands (claesbackman) at ${COMMANDS_DIR}:"
ls -1 "${COMMANDS_DIR}" 2>/dev/null | grep -E "^review-" || true
