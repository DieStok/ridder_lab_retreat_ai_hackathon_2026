# `idea4_local_review_pipeline_skills/` — Local IP-safe LLM grant/paper/code reviewer

For idea **#4**: send any document (grant proposal, paper draft, code) to a
**local** LLM and get a clear review with actionable insights. Inspired by
[isitcredible/reviewer2](https://github.com/isitcredible/reviewer2). The whole
point is privacy: nothing leaves the lab's HPC or laptop.

## Already in the hackathon repo (don't reinstall)

- `compound-engineering` (especially the various `ce-*-review` skills).
- `literature-review`, `scientific-writing` (K-Dense).
- `slack-bolt-app` for delivery.

## Skills in this pack

| # | Skill | Source | Why |
|---|-------|--------|-----|
| 1 | `AI-research-feedback` (review-paper, review-paper-light, review-paper-code, review-pap, review-grant) | `claesbackman/AI-research-feedback` | The most paper-shaped skill set in the public ecosystem. `review-paper` runs a 6-agent parallel review (spelling, internal consistency, unsupported claims, math, figures+tables, journal-specific adversary). `review-paper-code` checks code-vs-paper alignment for reproducibility. `review-pap` reviews pre-analysis plans. `review-grant` reviews grant proposals. Curl-installable as slash commands. |
| 2 | `cc-review` | `srinvias_mudavath/cc-review` | A pure-bash Claude Code skill that routes a `git diff` to *any* external LLM (Gemini, Ollama, DeepSeek, OpenAI). The killer feature for idea #4: an `Ollama: { private: true }` flag in the YAML config that **refuses** to send the diff to any cloud endpoint, even if the user fat-fingers an engine flag. Hard guardrail, not just a default. |
| 3 | `autoresearch` (uditgoenka) | `uditgoenka/autoresearch` | 11-command Karpathy-autoresearch port. Includes `/autoresearch:secure` (STRIDE / OWASP red team) and a `/autoresearch:debate` (5-expert convergence) — both useful as adversarial-review modes for grants and papers. Supports private flag for local Ollama. |
| 4 | `lcrawfurd/claude-skills` | `lcrawfurd/claude-skills` (paper-review subset) | Five-framework paper review (Edmans / Nyhan / Humphreys / Blattman + a fifth) + a 6-agent referee implementing Cunningham's MixtapeTools "Referee 2" protocol + a computational-reproducibility audit. Aimed at economists; the frameworks transfer. |
| 5 | `local_llm_routing_CLAUDE.md` (template, in this pack) | n/a | The most important file. Tells Claude Code to route to local Ollama / vLLM-MLX / llama.cpp via `ANTHROPIC_BASE_URL`, names the right open-weight models for the job (Qwen3.5-35B-A3B, GLM-4.7-Flash, Unsloth GGUF quants), and flags the **vLLM-MLX vs Ollama tool-use bug**: only vLLM-MLX implements the native Anthropic Messages API tool_use blocks; Ollama produces fake tool calls because of OpenAI↔Anthropic translation. |

## Recommended bundle

For a paper draft review: `review-paper` + `review-paper-code` + the
`local_llm_routing_CLAUDE.md` template. For a grant: `review-grant` +
`autoresearch /debate` mode + the routing template. For code: `cc-review`
with `private: true` on Ollama, plus the existing `compound-engineering`
review skills already in the repo.

## Caveats (IMPORTANT)

- **Ollama produces fake tool calls** when used with Claude Code. Tested
  on qwen3.5:9b, qwen3.5:35b-a3b, glm-4.7-flash. The Ollama→Claude Code
  translation layer drops `tool_use` content blocks. If your review pipeline
  needs Claude to call tools (read files, run linters), you can't use
  Ollama as the backend; use **vLLM-MLX** on Apple Silicon or **llama.cpp**
  with `llama-server` on Linux/CUDA. (Source: Vito Rallo's writeup
  in InfoSec Writeups, April 2026.)
- For pure text generation (review writing, no tool calls), Ollama is fine.
- The lab's HPC has GPUs — that's the right place to run llama.cpp
  with Qwen3.5-35B-A3B (Unsloth Dynamic GGUF quants); see Unsloth's docs
  for the exact `llama-server` flags. Set `ANTHROPIC_BASE_URL` on the
  laptop to point at the HPC node. Note `ANTHROPIC_API_KEY` may also need
  a dummy value depending on the server.
- **Don't run web-exposed APIs (e.g. `arxiv` MCP) on the HPC** — the
  brainstorm doc explicitly flags this. The local-LLM stack should be
  HPC-local; anything that fetches public data should run on the laptop
  inside the local-review loop.
- `claesbackman` skills install via `curl` to `~/.claude/commands/` — they
  are slash commands, not full skills. They run anywhere Claude Code runs
  but don't carry scripts/references; the review prompts are the whole
  payload.
