# CLAUDE.md — local-LLM routing for IP-safe review

For any review task on lab-confidential material (unsubmitted papers, draft
grants, unpublished code), Claude Code must route to a **local** model, not
to api.anthropic.com. This file tells the agent how, and warns about the
known sharp edges.

---

## TL;DR — the right backend

| Backend           | When to use                                         | Tool-use status                |
| ----------------- | --------------------------------------------------- | ------------------------------ |
| **vLLM-MLX**      | Apple Silicon laptop, ≥32 GB unified memory         | ✅ Native Anthropic tool_use    |
| **llama.cpp** (`llama-server`) | HPC GPU node, Linux + CUDA            | ✅ Works (with right config)    |
| **Ollama**        | Quick demo / text-only review with no tool calls    | ❌ Drops `tool_use` blocks     |
| **LM Studio**     | Same as Ollama — translation-layer issue            | ❌ Same problem as Ollama      |
| **Anthropic API** | **Never** — the whole point of idea #4 is local    | (n/a, intentionally avoided)   |

The Ollama / LM Studio issue is documented (Vito Rallo, *Running Claude
Code with local LLMs? all lies… until now*, InfoSec Writeups, April 2026):
the OpenAI↔Anthropic translation drops `tool_use` content blocks. Models
will *say* they used a tool but won't actually invoke it. For a pure-text
review (no file reads, no linter calls), Ollama is fine. For an agentic
review where Claude reads multiple files and runs commands, use vLLM-MLX
or llama.cpp.

## Recommended models (open-weight, agentic-capable)

| Model                | Where to get it                                  | Hardware                |
| -------------------- | ------------------------------------------------ | ----------------------- |
| **Qwen3.5-35B-A3B**  | Unsloth Dynamic GGUF on HF                       | 24 GB VRAM, ~17 GB Q4   |
| **Qwen3.5-27B**      | Unsloth GGUF                                     | 16 GB VRAM, ~2x slower  |
| **GLM-4.7-Flash**    | Unsloth GGUF                                     | Similar to Qwen3.5-35B  |
| **Qwen3-Coder-Next** | Unsloth — best if VRAM permits                   | ≥40 GB VRAM             |

For HPC: any of the above on a single A100 or H100. Use `llama-server`:

```bash
./llama.cpp/build/bin/llama-server \
  -m models/Qwen3.5-35B-A3B-Q4_K_M.gguf \
  --port 8001 \
  --n-gpu-layers 99 \
  --ctx-size 32768 \
  --jinja \
  --chat-template-file path/to/qwen-chat-template.jinja
```

The `--jinja` flag + the model's stock chat template is what gives you proper
tool_use serialization on llama.cpp (see Unsloth's Claude Code guide).

## Wiring Claude Code to it

```bash
# In your terminal, before launching Claude Code:
export ANTHROPIC_BASE_URL="http://hpc-node.local:8001"
export ANTHROPIC_API_KEY="sk-dummy-key"     # llama.cpp doesn't check
export ANTHROPIC_MODEL="qwen3.5-35b-a3b"     # match the served model
claude
```

Persist by adding the exports to `~/.bashrc` / `~/.zshrc`.

If Claude Code asks you to sign in on first run, edit `~/.claude.json`:

```json
{
  "hasCompletedOnboarding": true,
  "primaryApiKey": "sk-dummy-key"
}
```

To switch back to cloud Claude for non-IP-sensitive work:

```bash
unset ANTHROPIC_BASE_URL
```

## When the review is running

- Pass the document via file path, not pasted into the prompt — that way the
  agent reads it via `Read` tool, which means it stays on disk and never
  gets logged in any chat history that could leak.
- Output the review to a *gitignored* `reviews/` directory. `git ignore reviews/`
  before you start so a careless `git push` doesn't leak unsubmitted feedback.
- The `cc-review` skill's `private: true` flag on the Ollama engine config
  is a hard guardrail — it refuses to send the diff to any non-Ollama
  endpoint even if the engine flag is wrong. Use that pattern for any
  custom review wiring you add.

## What NOT to do

- Don't `cat paper.tex | claude -p "review this"` from a laptop with cloud
  Claude Code active — that's exactly the leak you're trying to prevent.
- Don't run paper-search MCPs (arXiv, PubMed, Semantic Scholar) from the
  HPC — the brainstorm doc explicitly flags this. Those go on the laptop
  alongside the local-LLM client.
- Don't put the full grant proposal in the system prompt of an HPC-hosted
  model and then shut down the model — some servers log prompts. Run a
  fresh `llama-server` per review with `--log-disable`.

## Verification checklist (run before relying on this for a real review)

```bash
# 1. Confirm the local server is responding
curl http://hpc-node.local:8001/v1/models

# 2. Confirm Claude Code is hitting it (not the cloud)
echo "what model are you?" | claude -p
# Should mention Qwen / GLM / whichever, not "Claude".

# 3. Confirm tool_use works
claude -p "Read README.md and tell me the first heading"
# Should call the Read tool, not hallucinate a heading.

# 4. Confirm no requests leave the lab network
sudo tcpdump -i any 'host api.anthropic.com'
# (Should be empty during a review session.)
```

If step 3 fails (tool_use ignored), you're on Ollama or LM Studio — switch
to vLLM-MLX (Apple Silicon) or llama.cpp with `--jinja` (everywhere else).
