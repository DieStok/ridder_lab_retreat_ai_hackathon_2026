# CLAUDE.md — Overnight optimization loop wrapper

Tells Claude how to run an autoresearch loop overnight on the lab HPC,
producing a morning report of which optimizations worked.

---

## What this loop does

1. Reads a target file (or set of files) from your project.
2. Establishes a baseline measurement (wall-clock or peak RSS or both).
3. Iteratively proposes one focused change per cycle (numba JIT, NumPy
   vectorization, joblib parallelism, Cython port, algorithm swap, …).
4. Runs the test suite + the benchmark.
5. If improved AND tests pass → keep + git commit. If worse OR tests fail
   → revert. If crashed → log + skip.
6. Repeats until N cycles or wall-clock budget exhausted.
7. At the end, writes `OPTIMIZATION_REPORT.md` with: baseline → final
   metric, list of accepted changes, list of attempted-and-rejected
   changes, list of crashes.

## Required inputs (don't start the loop without these)

- **Metric**: a single command that prints a number to stdout. e.g.
  `pytest tests/bench.py -k bench_main --benchmark-only --benchmark-min-rounds=10 -q | grep mean`
- **Direction**: minimize or maximize. (Default: minimize.)
- **Test suite**: full `pytest` (or `Rscript -e 'devtools::test()'`, etc.)
  must pass on every accepted change.
- **Scope**: one file or a small directory. Don't point the loop at
  100k lines of code.
- **Budget**: cycles (e.g. 50) AND wall-clock (e.g. 8h). Whichever hits
  first stops the loop.

## SLURM wrapper

```bash
#!/usr/bin/env bash
#SBATCH --job-name=claude-autoresearch
#SBATCH --partition=gpu        # or cpu — depends on whether the
#SBATCH --gres=gpu:1           #         local LLM needs GPU
#SBATCH --time=08:00:00
#SBATCH --mem=32G
#SBATCH --cpus-per-task=8
#SBATCH --output=logs/autoresearch_%j.log
#SBATCH --error=logs/autoresearch_%j.err

set -euo pipefail
cd "${PROJECT}/the-target-repo"
source .venv/bin/activate

# Local LLM via llama-server (see idea #4 routing CLAUDE.md)
# llama-server is assumed running on this node, port 8001.
export ANTHROPIC_BASE_URL="http://localhost:8001"
export ANTHROPIC_API_KEY="sk-dummy-key"
export ANTHROPIC_MODEL="qwen3.5-35b-a3b"

# Kick off the loop. Use uditgoenka/autoresearch's slash commands.
claude -p "$(cat <<EOF
Run /autoresearch:plan with:
  goal: minimize wall-clock time of \`pytest -k bench_main\`
  scope: src/hot_loop.py
  metric_command: pytest tests/bench.py -k bench_main --benchmark-min-rounds=10 -q
  test_command: pytest tests/ -q
  budget: 50 cycles or 7 hours, whichever hits first
  allowed_transforms:
    - numba.njit decoration (with cache=True)
    - NumPy vectorization (replace explicit Python loops)
    - joblib.Parallel for CPU-bound parallel-friendly work
    - Cython port (last resort; only if speedup > 5x is plausible)
    - algorithmic refactor (numerically equivalent only)
  forbidden_transforms:
    - changing public API
    - removing tests
    - downcasting precision (float64 -> float32) without an explicit comment

Then run /autoresearch:loop until budget exhausted.

At end, write OPTIMIZATION_REPORT.md and notify via:
  echo "claude-autoresearch \${SLURM_JOB_ID} done — see OPTIMIZATION_REPORT.md" \\
    | mail -s "autoresearch finished" \$USER
EOF
)"
```

Submit at end of day:

```bash
sbatch claude_autoresearch.sbatch
```

Wake up to `OPTIMIZATION_REPORT.md` + an email.

## Per-transform rules of thumb

| Transform              | When it helps                                | When it doesn't              |
| ---------------------- | -------------------------------------------- | ---------------------------- |
| **`@numba.njit`**      | Tight numeric loops on float/int arrays      | Short-lived scripts (compile time dominates), code that uses pandas / scikit-learn objects, or anything with non-numpy inputs |
| **NumPy vectorization**| Replacing explicit `for i in range(n):` loops over arrays | Loops where each iteration depends on the previous one (cumulative state) — those need `np.cumsum` / `np.cumprod` patterns or stay loops |
| **`joblib.Parallel`**  | Embarrassingly-parallel CPU-bound work, large per-task work | Small tasks (fork overhead dominates); IO-bound work (use `concurrent.futures.ThreadPoolExecutor`) |
| **Cython**             | Persistent libraries with hot inner functions | One-off scripts; codebases with no build system in place |
| **Algorithmic swap**   | When profiler says the bottleneck is a quadratic loop | Always-first option to consider; algorithmic wins beat micro-optimizations |

The loop should *always* try algorithmic swaps before language-level
optimizations. Tell `/autoresearch:plan` to bias that way.

## Report format

```markdown
# Overnight optimization report — {{date}} — job {{slurm_id}}

**Target:** `{{file}}`
**Baseline:** {{baseline_metric}}{{units}}
**Final:**    {{final_metric}}{{units}}  ({{speedup}}× faster)
**Cycles run:** {{n}} ({{n_accepted}} accepted, {{n_rejected}} rejected, {{n_crashed}} crashes)

## Accepted changes
1. **Cycle {{i}}** — {{commit_sha}} — {{description}} — {{baseline}} → {{after}} ({{delta}}%)
2. ...

## Notable rejected changes
- Cycle {{i}}: numba JIT on `inner_loop` — broke test_consistency, reverted.
- Cycle {{j}}: Cython port of `parser` — only 1.04× speedup, not worth build complexity.

## Crashes / skipped
- Cycle {{k}}: numba couldn't compile because of `dict` argument.

## Recommended merges
{{Top 3 changes by speedup-without-risk. The user should review these
before merging — autoresearch's tests are necessary but not sufficient.}}
```

## Don't

- Don't run more than one loop on the same file in parallel — git
  conflicts.
- Don't target a file that's actively being edited by a teammate. The
  loop branches off `HEAD`; any divergence wastes the night.
- Don't trust a "10× speedup" without a manual perf review the next
  morning. Numba sometimes silently changes numeric precision; always
  cross-check on real data.
- Don't optimize code that's not actually a bottleneck. Profile first
  with `cProfile` or `py-spy` to confirm the target is on the critical
  path. The loop will happily make irrelevant code 10× faster.
