#!/usr/bin/env bash
# install.sh — skill pack for hackathon idea #7 (automated code optimization).
set -euo pipefail
REPO_ROOT="$(pwd)"
SKILLS_DIR="${REPO_ROOT}/.agents/skills"
TMP="${TMPDIR:-/tmp}/idea7-install"
mkdir -p "${SKILLS_DIR}" "${TMP}"
echo "==> Installing into ${SKILLS_DIR}"

# ---- uditgoenka/autoresearch (11 commands, pick this first) ----------
echo "==> uditgoenka/autoresearch"
rm -rf "${TMP}/autoresearch"
git clone --depth 1 https://github.com/uditgoenka/autoresearch "${TMP}/autoresearch" || \
  echo "WARN: clone failed"
if [ -d "${TMP}/autoresearch" ]; then
  cp -r "${TMP}/autoresearch" "${SKILLS_DIR}/autoresearch"
  echo "  installed autoresearch"
  echo "  Run install.sh in ${SKILLS_DIR}/autoresearch to register the 11 slash commands."
fi

# ---- drivelineresearch/autoresearch-claude-code (alt) -----------------
echo "==> drivelineresearch/autoresearch-claude-code (alternative)"
rm -rf "${TMP}/autoresearch-cc"
git clone --depth 1 https://github.com/drivelineresearch/autoresearch-claude-code "${TMP}/autoresearch-cc" || \
  echo "WARN: clone failed"
if [ -d "${TMP}/autoresearch-cc" ]; then
  cp -r "${TMP}/autoresearch-cc" "${SKILLS_DIR}/autoresearch-cc"
  echo "  installed autoresearch-cc (alternative; pick one or the other)"
fi

# ---- Posit critical-code-reviewer ------------------------------------
echo "==> Posit critical-code-reviewer (open-source category)"
cat <<'EOF'
  In Claude Code, run:
      /plugin marketplace add posit-dev/skills
      /plugin install open-source@posit-dev-skills
  This installs critical-code-reviewer (adversarial review across Python,
  R, JS/TS, SQL, front-end) and describe-design.

  Or via npx:
      npx skills add posit-dev/skills --skill critical-code-reviewer -a claude-code -y
EOF

# ---- Muminur autoresearch-skill (alt; stricter goal decomp) ----------
echo "==> Muminur/autoresearch-skill-Andrej-Karpathy (optional)"
rm -rf "${TMP}/autoresearch-muminur"
git clone --depth 1 https://github.com/Muminur/autoresearch-skill-Andrej-Karpathy "${TMP}/autoresearch-muminur" 2>/dev/null && \
  cp -r "${TMP}/autoresearch-muminur" "${SKILLS_DIR}/autoresearch-muminur" && \
  echo "  installed autoresearch-muminur" || \
  echo "  WARN: clone failed (optional, skip)"

# ---- optimization-loop CLAUDE.md ------------------------------------
if [ -f "$(dirname "$0")/optimization_loop_CLAUDE.md" ]; then
  echo "==> optimization_loop_CLAUDE.md available"
  echo "  Copy → your project root for the SLURM wrapper template."
fi

# ---- symlink ---------------------------------------------------------
if [ ! -e "${REPO_ROOT}/.claude/skills" ]; then
  mkdir -p "${REPO_ROOT}/.claude"
  ln -s ../.agents/skills "${REPO_ROOT}/.claude/skills"
  echo "==> Symlinked .claude/skills -> .agents/skills"
fi

echo
echo "==> Done. Installed under ${SKILLS_DIR}:"
ls -1 "${SKILLS_DIR}" 2>/dev/null
