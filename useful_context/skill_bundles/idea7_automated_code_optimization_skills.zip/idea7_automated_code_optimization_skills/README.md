# `idea7_automated_code_optimization_skills/` — Overnight code optimization on the HPC

For idea **#7**: a local-LLM agent runs overnight against committed (or
user-selected) code on the HPC, profiling, trying speed-ups (numba,
Cython, joblib, NumPy vectorization), and emitting a morning report of
what worked. The brainstorm doc points to Karpathy's `autoresearch`,
HuggingFace `ml-intern`, and SkyPilot's research-agents post as inspiration.

## Already in the hackathon repo (don't reinstall)

- `compound-engineering` — has `ce-test-browser`, code-review skills,
  iteration loops.
- `hpc-cluster` (lab-internal) — SLURM syntax for the lab cluster.

## Skills in this pack

| # | Skill | Source | Why |
|---|-------|--------|-----|
| 1 | `autoresearch` (uditgoenka, 11 commands) | `uditgoenka/autoresearch` | The most maintained Karpathy-port: `/autoresearch:plan` (goal + metric + scope), `/autoresearch:loop` (modify → verify → keep/discard → repeat), `/autoresearch:debug`, `/autoresearch:fix`, `/autoresearch:secure`, `/autoresearch:ship`, plus `:probe`, `:scenario`, `:predict`, `:learn`, `:reason`. Does git-based commit-or-revert per change automatically. Supports private flag for local Ollama. |
| 2 | `autoresearch-claude-code` (drivelineresearch) | `drivelineresearch/autoresearch-claude-code` | Pure-skill port of pi-autoresearch — no MCP server, just instructions the agent follows with built-in tools. Cleaner if you don't need the 11-command surface area. Creates a session branch, writes a benchmark script, runs a baseline, then loops. State in JSONL. |
| 3 | `autoresearch-skill-Andrej-Karpathy` (Muminur) | `Muminur/autoresearch-skill-Andrej-Karpathy` | A more rigorous take: 7-component goal decomposition (metric, direction, target, scope, data source, verification command, regression tests). Good if you want the agent to push back on under-specified goals before starting. |
| 4 | `cc-review` | (DEV.to writeup) | The any-LLM diff reviewer (also listed in idea #4). For idea #7, useful as a *second pair of eyes* on each accepted change — let Gemini or local Ollama review what Claude just optimized, before merging. |
| 5 | `python-pro` (community) | various | Generic Python-quality skill. Layered under autoresearch so the loop's "modify" step proposes idiomatic numba / Cython / NumPy / joblib refactors instead of grab-bag changes. |
| 6 | `posit-dev critical-code-reviewer` | `posit-dev/skills` (open-source category) | Adversarial code-review skill from Posit that surfaces lazy patterns, edge cases, security holes — useful as the gate function on whether a "faster" change is also "safer". Multilingual (Python, R, JS/TS, SQL, front-end). |
| 7 | `optimization_loop_CLAUDE.md` (template, in this pack) | n/a | The orchestrator: how to wire autoresearch's loop to a SLURM `sbatch` wrapper, how to define the metric (wall-clock, peak RSS, or a domain metric), what to feed numba/Cython/joblib as candidate transforms, what reports to emit at 9 AM. |

## Recommended bundle

`uditgoenka/autoresearch` (the loop engine) + `posit-dev critical-code-reviewer`
(the gate function before commits) + the `optimization_loop_CLAUDE.md`
template (the SLURM wrapper). Add `cc-review` if you want a second-LLM
eye on each diff. Skip the other autoresearch ports unless you specifically
prefer their philosophy (Muminur for stricter goal decomposition;
drivelineresearch for plugin-form simplicity).

## Caveats (important — read before committing time to this idea)

- **Autoresearch needs a measurable, automatable metric.** "Make it
  faster" works (wall-clock from `pytest -k bench` or `hyperfine`).
  "Make it cleaner" doesn't (no metric). Pick one numeric thing per
  loop and stick with it.
- **Numba / Cython / joblib aren't always wins.** Numba JIT compile time
  can dominate for short scripts. Cython requires a build step that
  breaks `pip install -e .` workflows. Joblib's process-based parallelism
  has fork-overhead that beats it on small inputs. The autoresearch loop
  must include a *baseline run on production-shape input data* — synthetic
  benchmarks lie.
- **Run on the HPC overnight, not on a laptop.** The 5-min budget per
  experiment that Karpathy's autoresearch uses → ~100 experiments per
  night → 8h SLURM job. The brainstorm doc's pointer to the SkyPilot
  research-driven agents post is the right reference for the
  multi-experiment topology.
- **Privacy.** This runs local-LLM (idea #4 stack) by default. Don't let
  the loop ship code to a cloud LLM. Use the `private: true` guardrail
  pattern from `cc-review`.
- **Test suite must be solid.** The loop's revert-on-regression mechanism
  only works if your tests catch regressions. Spend 10 minutes adding
  property-based tests with Hypothesis if you don't have them — better
  than a "fast" change that silently corrupts results.
