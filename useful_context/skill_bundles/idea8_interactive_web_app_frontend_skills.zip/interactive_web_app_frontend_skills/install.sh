#!/usr/bin/env bash
# install.sh — skill pack for hackathon idea #8 (interactive demos / paper websites).
# Run from the root of your hackathon checkout (contains .agents/skills/).
# Each section is independent — comment out the framework paths you don't need.

set -euo pipefail

REPO_ROOT="$(pwd)"
SKILLS_DIR="${REPO_ROOT}/.agents/skills"
TMP="${TMPDIR:-/tmp}/iwafs-install"

mkdir -p "${SKILLS_DIR}" "${TMP}"
echo "==> Installing into ${SKILLS_DIR}"

# =========================================================================
# Framework paths — pick one (or two), comment out the rest
# =========================================================================

# ---- Quarto path (Posit official) -------------------------------------
echo "==> Posit Quarto skills (official)"
cat <<'EOF'
  In a Claude Code session, run:
      /plugin marketplace add posit-dev/skills
      /plugin install quarto@posit-dev-skills
  This installs the quarto-authoring skill (Quarto CLI v1.8+, hashpipe
  cell options, cross-references, callouts, RMarkdown migration).

  Or use the npx CLI:
      npx skills add posit-dev/skills --skill quarto-authoring -a claude-code -y
EOF

# ---- Marimo path -----------------------------------------------------
echo "==> Marimo skills"
rm -rf "${SKILLS_DIR}/marimo-pair"
git clone --depth 1 https://github.com/marimo-team/marimo-pair "${SKILLS_DIR}/marimo-pair" || \
  echo "WARN: marimo-pair clone failed — install manually."
echo "  NOTE: also add koaning's marimo CLAUDE.md to your project root if useful:"
echo "        https://gist.github.com/koaning/ce4786b532f1e0477bc89bd804907e40"

# ---- Shiny path: official Posit, with Python crib if you're using py-shiny --
echo "==> Posit Shiny skills (official)"
cat <<'EOF'
  In a Claude Code session, run:
      /plugin marketplace add posit-dev/skills
      /plugin install shiny@posit-dev-skills
  Or via npx:
      npx skills add posit-dev/skills --skill shiny-bslib --skill shiny-bslib-theming --skill brand-yml -a claude-code -y

  HONEST CAVEAT for Shiny for Python (py-shiny):
  - shiny-bslib and shiny-bslib-theming have R-only code examples (the Posit
    category README claims dual-language support, but in practice the SKILLs
    teach R syntax: bs_theme(), thematic::thematic_shiny(), library(bslib)).
  - brand-yml IS genuinely dual-language (it ships shiny-r.md + shiny-python.md).
  - The layout vocabulary (page_sidebar, card, value_box, layout_columns)
    is identical in both languages by design — Claude can translate, but it
    helps to give it a crib sheet.
  - This pack ships shiny_for_python_CLAUDE.md — drop it at your project root
    if your demo is py-shiny, and Claude will produce Python idioms instead
    of R-translated ones.
EOF
# Auto-copy the CLAUDE.md template if a py-shiny project is detected,
# otherwise leave it in the pack and let the user copy it manually.
if [ -f "${REPO_ROOT}/app.py" ] || grep -q "^shiny" "${REPO_ROOT}/requirements.txt" 2>/dev/null || \
   grep -q "shiny" "${REPO_ROOT}/pyproject.toml" 2>/dev/null; then
  if [ -f "$(dirname "$0")/shiny_for_python_CLAUDE.md" ] && [ ! -f "${REPO_ROOT}/CLAUDE.md" ]; then
    cp "$(dirname "$0")/shiny_for_python_CLAUDE.md" "${REPO_ROOT}/CLAUDE.md"
    echo "  copied shiny_for_python_CLAUDE.md → ${REPO_ROOT}/CLAUDE.md"
  fi
fi

# ---- Flask path -------------------------------------------------------
echo "==> Flask skills"
mkdir -p "${SKILLS_DIR}/flask-setup"
curl -fsSL "https://claude-skills-hub.vercel.app/skills/python/flask-setup.md" \
  -o "${SKILLS_DIR}/flask-setup/SKILL.md" 2>/dev/null || \
  echo "WARN: flask-setup curl failed — fetch manually from clskillshub.com"
cat <<'EOF'
  For a fuller Flask skill (application factory, blueprints, SQLAlchemy,
  JWT), browse:
      https://mcpmarket.com/tools/skills/flask-api-development
  and copy its SKILL.md into ${SKILLS_DIR}/flask-api/.
EOF

# ---- Django path ------------------------------------------------------
echo "==> Django skills"
if command -v npx >/dev/null 2>&1; then
  npx --yes skills add saaspegasus/django-skills -a claude-code -y || \
    echo "WARN: saaspegasus/django-skills install failed — try interactively"
else
  echo "  WARN: npx not found — install Node.js >= 18"
fi
rm -rf "${TMP}/claude-code-django"
git clone --depth 1 https://github.com/kjnez/claude-code-django "${TMP}/claude-code-django" || \
  echo "WARN: kjnez/claude-code-django clone failed"
if [ -d "${TMP}/claude-code-django/.claude/skills" ]; then
  for s in "${TMP}/claude-code-django/.claude/skills"/*/; do
    name="$(basename "$s")"
    [ "$name" = "skill-creator" ] && continue   # already in the repo
    cp -r "$s" "${SKILLS_DIR}/django-${name}"
    echo "  installed django-${name}"
  done
fi
cat <<'EOF'
  For a senior Django specialist persona (Django 5.0, DRF, async views,
  select_related/prefetch_related discipline) see:
      https://jeffallan.github.io/claude-skills/skills/backend/django-expert/
  and copy its SKILL.md into ${SKILLS_DIR}/django-expert/.
EOF

# =========================================================================
# Cross-framework additions
# =========================================================================

# ---- Vercel skills (web-design-guidelines etc) -----------------------
echo "==> Vercel frontend skills"
if command -v npx >/dev/null 2>&1; then
  npx --yes skills add vercel-labs/agent-skills \
    --skill web-design-guidelines \
    --skill agent-browser \
    -a claude-code -y || echo "WARN: npx skills install partially failed"
else
  echo "  WARN: npx not found"
fi

# ---- Anthropic example skills (theme-factory, webapp-testing, web-artifacts-builder)
echo "==> Anthropic example-skills (manual /plugin step)"
cat <<'EOF'
  In Claude Code, run:
      /plugin marketplace add anthropics/skills
      /plugin install example-skills@anthropic-agent-skills
  This installs theme-factory, web-artifacts-builder, webapp-testing.
EOF

# ---- Browser self-review (lackeyjb playwright) ------------------------
echo "==> playwright-skill (lackeyjb)"
rm -rf "${TMP}/playwright-skill"
git clone --depth 1 https://github.com/lackeyjb/playwright-skill "${TMP}/playwright-skill" || \
  echo "WARN: playwright-skill clone failed"
if [ -d "${TMP}/playwright-skill/skills/playwright-skill" ]; then
  cp -r "${TMP}/playwright-skill/skills/playwright-skill" "${SKILLS_DIR}/"
  echo "  installed playwright-skill"
fi

# ---- Diataxis docs ---------------------------------------------------
echo "==> Diataxis docs skill (sammcj)"
rm -rf "${TMP}/sammcj-agentic"
git clone --depth 1 https://github.com/sammcj/agentic-coding "${TMP}/sammcj-agentic" || \
  echo "WARN: sammcj/agentic-coding clone failed"
if [ -d "${TMP}/sammcj-agentic/diataxis-documentation" ]; then
  cp -r "${TMP}/sammcj-agentic/diataxis-documentation" "${SKILLS_DIR}/writing-documentation-with-diataxis"
  echo "  installed writing-documentation-with-diataxis"
fi

# =========================================================================
# React-only — comment out unless you're going React/Next
# =========================================================================
echo "==> React-only skills (skip if not using React)"
# if command -v npx >/dev/null 2>&1; then
#   npx --yes skills add vercel-labs/agent-skills \
#     --skill vercel-react-best-practices \
#     --skill composition-patterns \
#     --skill view-transition-api \
#     -a claude-code -y || echo "WARN: Vercel React skills install failed"
# fi
# echo "  shadcn (in your React project root): npx shadcn@latest add skill"
# rm -rf "${TMP}/Shadcnblocks-Skill"
# git clone --depth 1 https://github.com/masonjames/Shadcnblocks-Skill "${TMP}/Shadcnblocks-Skill" || true
# [ -d "${TMP}/Shadcnblocks-Skill/skills/shadcn-ui" ] && cp -r "${TMP}/Shadcnblocks-Skill/skills/shadcn-ui" "${SKILLS_DIR}/shadcnblocks"
# rm -rf "${TMP}/jez-claude-skills"
# git clone --depth 1 https://github.com/jezweb/claude-skills "${TMP}/jez-claude-skills" || true
# [ -d "${TMP}/jez-claude-skills/tailwind-theme-builder" ] && cp -r "${TMP}/jez-claude-skills/tailwind-theme-builder" "${SKILLS_DIR}/"

# =========================================================================
# Make Claude Code see them
# =========================================================================
if [ ! -e "${REPO_ROOT}/.claude/skills" ]; then
  mkdir -p "${REPO_ROOT}/.claude"
  ln -s ../.agents/skills "${REPO_ROOT}/.claude/skills"
  echo "==> Symlinked .claude/skills -> .agents/skills"
fi

echo
echo "==> Done. Installed under ${SKILLS_DIR}:"
ls -1 "${SKILLS_DIR}" 2>/dev/null
