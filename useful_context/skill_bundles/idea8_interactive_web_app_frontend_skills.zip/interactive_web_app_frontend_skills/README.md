# `interactive_web_app_frontend_skills/` — skill pack for hackathon idea #8

Skills for hackathon brainstorm idea #8: *generating interactive demos and paper
websites for papers (or datasets)* — using **Quarto, Marimo, Shiny for Python,
Flask, or Django**.

Skills already in the hackathon repo (`frontend-design`, all of
`compound-engineering`, `paper-lookup`, `literature-review`, `scientific-writing`,
`skill-creator`, `slack-bolt-app`) are **not** re-listed here. This pack contains
only the additions.

## Path-by-path: what to install for which framework

The five frameworks idea #8 names are not equivalent — pick **one path** per
team, not all five.

| Framework path        | Install                                                                  |
| --------------------- | ------------------------------------------------------------------------ |
| **Quarto**            | `posit-dev/skills` → `quarto` plugin (the `quarto-authoring` skill)      |
| **Marimo**            | `marimo-team/marimo-pair` (drops Claude into a running marimo session)   |
| **Shiny for Python**  | `posit-dev/skills` → `shiny` plugin **+ a project-level CLAUDE.md** (see "Shiny for Python honest caveat" below). The `brand-yml` skill is genuinely dual-language; `shiny-bslib` and `shiny-bslib-theming` are R-shaped in practice and need a Python crib sheet to be useful. |
| **Flask**             | `clskillshub` `flask-setup` (curl install) + `mcpmarket` `flask-api-development` |
| **Django**            | `saaspegasus/django-skills` (`npx skills add`) + `kjnez/claude-code-django` (full Django CC config example) + `jeffallan/claude-skills` `django-expert` |

Posit officially maintains skills for Quarto and Shiny — that's the canonical
source. **Quarto is genuinely language-agnostic** (R / Python / Julia chunks all
supported by `quarto-authoring`). **Shiny is more nuanced**: the Posit category
README claims dual-language support, but in practice only `brand-yml` ships
both an `shiny-r.md` and a `shiny-python.md` reference. `shiny-bslib` and
`shiny-bslib-theming` are R-shaped (R syntax in every example, `bs_theme()`,
`thematic::thematic_shiny()`, the migration guide is from R-Shiny primitives).
See the "Shiny for Python honest caveat" section below for what to add for
the Python path.

## Cross-framework additions (install once regardless of framework)

| Skill | One-line description |
|-------|----------------------|
| `web-design-guidelines` (vercel-labs) | Audits any HTML/CSS/JS against the live Web Interface Guidelines (~100 rules: a11y, perf, focus states, ARIA). Run before declaring the demo done. |
| `web-artifacts-builder` (anthropics) | Build single-file React + Tailwind + shadcn artifacts. Useful if your demo will be embedded in a Claude.ai Artifact or shared as a one-file HTML preview. |
| `theme-factory` (anthropics) | Generates / applies professional themes to artifacts and websites — design tokens once, applied everywhere. |
| `webapp-testing` (anthropics) | Playwright-based local UI verification + screenshot capture, against a local dev server. |
| `playwright-skill` (lackeyjb) | Model-invoked Playwright skill: Claude writes and runs Playwright code on the fly. Visible browser by default — good for "does the demo work?" checks during the hackathon. |
| `agent-browser` (vercel-labs) | A browser primitive for agents (~187K installs). Lighter alternative to Playwright if you only need open-page-and-screenshot. |
| `writing-documentation-with-diataxis` (sammcj) | Forces tutorials / how-to / reference / explanation separation for the demo's prose pages. |

## React-only additions (install only if your demo is a React/Next app)

Don't install these for Quarto/Marimo/Shiny/Flask/Django demos — they're React-specific.

| Skill | One-line description |
|-------|----------------------|
| `vercel-react-best-practices` (vercel-labs) | Prioritized React/Next.js perf rules from Vercel Engineering. |
| `composition-patterns` (vercel-labs) | React composition patterns that scale — kills boolean-prop sprawl. |
| `view-transition-api` (vercel-labs) | Native-feeling animations using React's View Transition API + Next.js `next/link`. |
| `shadcn` (official, ui.shadcn.com) | Reads your `components.json` and generates correct shadcn/ui code first try. |
| `Shadcnblocks-Skill` (masonjames) | 2,500+ pre-built shadcn blocks. Polished landing page in 50 minutes. |
| `tailwind-theme-builder` (jezweb) | CSS variables + ThemeProvider + dark mode. Pairs with shadcn. |

## Recommended bundles by path

A team has 50 minutes. Don't install everything — pick one row.

**Quarto path (academic publishing aesthetic):**
`quarto-authoring` (Posit) + `web-design-guidelines` + `playwright-skill` + `writing-documentation-with-diataxis`.

**Marimo path (reactive Python WASM, Pyodide):**
`marimo-pair` + koaning's CLAUDE.md + `web-design-guidelines` + `playwright-skill`.

**Shiny for Python path (the dashboard/widget aesthetic):**
`shiny-bslib` + `brand-yml` from Posit (the layout concepts in `shiny-bslib`
mostly transfer because py-shiny mirrors bslib's API, but you must mentally
translate R `bs_theme()` / `card()` to py-shiny `ui.Theme.from_brand()` /
`ui.card()`) **+ a project `CLAUDE.md`** that pins the agent to py-shiny docs
and the `posit-dev/py-shiny` repo for concrete examples. See
`shiny_for_python_CLAUDE.md` in this pack for a starting template.
Plus `web-design-guidelines` + `playwright-skill`.

**Shiny for R path** (in case anyone in the lab uses R): the Posit Shiny
plugin is a clean fit — `shiny-bslib` + `shiny-bslib-theming` + `brand-yml`,
no Python crib sheet needed.

### Shiny for Python honest caveat

The Posit `shiny` plugin's category README claims it supports both Shiny for
R and Shiny for Python, and the marketing is true at the *concept* level —
py-shiny was built to mirror bslib's API, so the layout vocabulary
(`page_sidebar`, `card`, `value_box`, `layout_columns`) is the same in both
languages. But the SKILL.md files in `shiny-bslib` and `shiny-bslib-theming`
have only R code examples and reference R-only ergonomics like
`thematic::thematic_shiny()` and Sass-via-`bs_theme(...)`. Claude can usually
translate, but it's not as crisp as a native Python skill would be.
The one skill that *is* truly dual-language is `brand-yml` — it ships both
`references/shiny-r.md` and `references/shiny-python.md`.

Two ways to close the gap:

1. **Ship `shiny_for_python_CLAUDE.md`** (in this pack) at your project root.
   It tells Claude to load the Posit Shiny skill *and* prefer py-shiny idioms
   (`from shiny import App, ui, render, reactive`, `@reactive.calc`,
   `@render.plot`, `ui.Theme.from_brand(__file__)`, Express vs Core).
2. **Lean on `brand-yml`** — that's the one Posit Shiny skill where Python
   and R get equal treatment.

**Flask path (when you need server-side state but minimal scaffolding):**
`flask-setup` + `flask-api-development` + `web-design-guidelines` + `playwright-skill`.
For a polished UI, layer on `tailwind-theme-builder`.

**Django path (when the demo doubles as an internal tool with auth, ORM, admin):**
`django-skills` (saaspegasus) + `claude-code-django` (kjnez) + `django-expert` (jeffallan) + `web-design-guidelines` + `playwright-skill`.

## Install

`install.sh` runs every install command; comment out the sections you don't
need. After install:

```bash
mkdir -p .claude && ln -s ../.agents/skills .claude/skills
```

…the same pattern the rest of the hackathon repo uses.

## Caveats (be honest)

- These skills are referenced, not vendored. The install commands pull them
  from upstream at install time. Run `install.sh` once on a connected machine
  and commit `.agents/skills/` to your branch if you need them offline.
- Skills assume `git`, `npx`, and Node ≥ 18.
- The Vercel `npx skills` CLI auto-detects Claude Code; confirm with
  `npx skills list`.
- The Flask community skills (`clskillshub`, `mcpmarket`) are single-author and
  smaller in scope than the Django/Posit options — fine for hackathon scaffolding,
  not a curated multi-skill ecosystem like Django has.
- `posit-dev/skills` is the official Posit repo. The `shiny` plugin works for
  Shiny for R *and* Shiny for Python; the SKILL.md routes based on which one
  you're using.
