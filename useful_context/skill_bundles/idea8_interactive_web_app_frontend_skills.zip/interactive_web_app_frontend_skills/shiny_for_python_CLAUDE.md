# CLAUDE.md — Shiny for Python project crib

Drop this at your project root if your idea-#8 demo is a **Shiny for Python**
app. It tells Claude to use the Posit Shiny skill at the concept level, but
to prefer py-shiny syntax in actual code.

The Posit `shiny-bslib` SKILL.md is written for Shiny for R. The layout
vocabulary (page_sidebar, card, value_box, layout_columns) is the same across
both languages — Posit deliberately mirrored bslib's API in py-shiny — but the
function-call syntax and ergonomics differ. When Claude reads this CLAUDE.md
along with the Posit skill, it should produce idiomatic py-shiny.

---

## This is a Shiny for Python project

- The framework is **`shiny`** (a.k.a. py-shiny / Shiny for Python), not Shiny for R.
- Imports: `from shiny import App, ui, render, reactive` (Core mode) or
  `from shiny.express import input, render, ui` (Express mode).
- Run with `shiny run app.py --reload --launch-browser` or `shiny run --reload .`.
- Scaffold with `shiny create` (interactive template picker).

## Translation table (R Shiny → py-shiny)

When the Posit `shiny-bslib` skill suggests R syntax, translate it like this:

| R-Shiny / bslib (skill examples)             | py-shiny (use this instead)                                  |
| -------------------------------------------- | ------------------------------------------------------------ |
| `library(shiny); library(bslib)`             | `from shiny import App, ui, render, reactive`                |
| `page_sidebar(...)`                          | `ui.page_sidebar(...)`                                       |
| `page_navbar(...)`                           | `ui.page_navbar(...)`                                        |
| `page_fillable(...)` / `page_fluid(...)`     | `ui.page_fillable(...)` / `ui.page_fluid(...)`               |
| `sidebar(...)`                               | `ui.sidebar(...)`                                            |
| `card(full_screen = TRUE, ...)`              | `ui.card(ui.card_header(...), ..., full_screen=True)`        |
| `card_header("Plot")`                        | `ui.card_header("Plot")`                                     |
| `value_box(title=..., value=..., theme=...)` | `ui.value_box("title", "value", theme="primary")`            |
| `layout_column_wrap(width = 1/3, ...)`       | `ui.layout_column_wrap(*children, width=1/3)`                |
| `layout_columns(...)`                        | `ui.layout_columns(*children)`                               |
| `selectInput("x", "X variable", choices)`    | `ui.input_select("x", "X variable", choices)`                |
| `plotOutput("scatter")`                      | `ui.output_plot("scatter")`                                  |
| `tableOutput("tbl")`                         | `ui.output_table("tbl")`                                     |
| `output$plot <- renderPlot({ ... })`         | `@render.plot\ndef scatter(): ...`                           |
| `reactive({ ... })`                          | `@reactive.calc` (NOT `@reactive.Calc` — lower-case is current) |
| `observe({ ... })`                           | `@reactive.effect`                                           |
| `bs_theme(version = 5)`                      | `theme=ui.Theme.from_brand(__file__)` (or omit; bslib is bundled) |
| `thematic::thematic_shiny()` (server)        | matplotlib `style.use("dark_background")` or set globally; no thematic equivalent in py-shiny |
| `req(input$species)` (server-side guard)     | `req(input.species())` — note the `()`; py-shiny inputs are callables |

## py-shiny idioms the R skill won't teach you

- **Express vs Core mode**: Express is the easier ramp (single-file, top-level
  layout); Core is the App-Server-UI pattern. The Posit examples are Core.
- Inputs are **called** like functions in py-shiny: `input.x()` not `input$x`.
- Reactive primitives are decorators: `@reactive.calc`, `@reactive.effect`,
  `@reactive.event(input.btn)`. The lowercase form is the current API
  (`reactive.Calc`/`reactive.Effect` were renamed; old code still works but
  emits warnings).
- Render decorators: `@render.plot` (matplotlib/seaborn/plotnine),
  `@render.table` (pandas/polars/narwhals), `@render.data_frame` (interactive
  with sort/filter/edit), `@render.text`, `@render.ui`.
- Data-frame outputs accept any narwhals-supported eager data frame
  (pandas, polars, pyarrow, modin) — no R-style coercion.
- File structure for a single-file app: `app.py` containing `app_ui`, `server`,
  and `app = App(app_ui, server)`. For Express: just write top-level statements
  with `from shiny.express import input, render, ui`.

## Theming with brand.yml (this part *is* dual-language)

The `brand-yml` skill from `posit-dev/skills` is genuinely dual-language —
it has both `references/shiny-r.md` and `references/shiny-python.md`. Use it
without translation. The py-shiny side looks like:

```python
from shiny import App, ui

app_ui = ui.page_fluid(
    theme=ui.Theme.from_brand(__file__),
    # ... rest of UI
)
```

Place a `_brand.yml` next to `app.py`; py-shiny auto-discovers it.

## Deployment options for the demo

- **Shinylive** (Pyodide / WASM, fully static): `shiny export myapp site/`
  then deploy the `site/` to GitHub Pages, Netlify, Hugging Face Spaces, or
  any static host. **Caveat**: not every Python package is in Pyodide — anything
  with C extensions outside scientific Python may not work. OR-Tools and
  Gurobi specifically don't work; numpy / pandas / scipy / matplotlib / scikit-learn do.
- **shinyapps.io** (Posit-hosted): `rsconnect-python deploy shiny <dir>`.
- **Posit Connect Cloud** (free tier): connect a GitHub repo and click
  deploy.
- **Hugging Face Spaces**: pick the Shiny SDK; works for both R and Python
  Shiny.
- **Self-host**: any Linux box with Python; `shiny run app.py --host 0.0.0.0`
  behind nginx.

## Reference URLs Claude should fetch when unsure

- Top-level docs: https://shiny.posit.co/py/
- Component gallery: https://shiny.posit.co/py/components/
- Layouts gallery: https://shiny.posit.co/py/layouts/
- Source repo + examples: https://github.com/posit-dev/py-shiny
- Shinylive examples: https://shinylive.io/py/examples/
- LLM integration (chatlas, ellmer-py): https://shiny.posit.co/py/docs/genai-chatbots.html

## When the Posit `shiny-bslib` SKILL.md trips you up

If `shiny-bslib` produces R code, **say "translate to py-shiny"** and Claude
will rerun against this CLAUDE.md. The skill's *concepts* (favor `page_sidebar`
over legacy `page_fluid` + `sidebarLayout`; use `layout_column_wrap` for
responsive grids; wrap outputs in `card(full_screen=True)` for dashboards;
group sidebar inputs in `accordion` when there are many controls) all transfer.
