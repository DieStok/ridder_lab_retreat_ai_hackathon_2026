#!/usr/bin/env bash
# install.sh — skill pack for hackathon idea #1 (personal reading digest).
# Run from the root of the hackathon checkout (contains .agents/skills/).

set -euo pipefail
REPO_ROOT="$(pwd)"
SKILLS_DIR="${REPO_ROOT}/.agents/skills"
TMP="${TMPDIR:-/tmp}/idea1-install"
mkdir -p "${SKILLS_DIR}" "${TMP}"
echo "==> Installing into ${SKILLS_DIR}"

# ---- AI-Briefing-Skill (the multi-source digest engine) ----------------
echo "==> AI-Briefing-Skill (KiKi-Builds)"
rm -rf "${TMP}/AI-Briefing-Skill"
git clone --depth 1 https://github.com/KiKi-Builds/AI-Briefing-Skill "${TMP}/AI-Briefing-Skill" || \
  echo "WARN: clone failed — install manually from https://github.com/KiKi-Builds/AI-Briefing-Skill"
if [ -d "${TMP}/AI-Briefing-Skill" ]; then
  cp -r "${TMP}/AI-Briefing-Skill" "${SKILLS_DIR}/ai-briefing"
  echo "  installed ai-briefing"
fi

# ---- paper-search-mcp (alternative source layer to paper-lookup) -------
echo "==> paper-search-mcp (openags)"
rm -rf "${TMP}/paper-search-mcp"
git clone --depth 1 https://github.com/openags/paper-search-mcp "${TMP}/paper-search-mcp" || \
  echo "WARN: clone failed"
# This is an MCP server, not a SKILL.md — leaving it in TMP for the team
# to wire up via .mcp.json. README.md explains.
if [ -d "${TMP}/paper-search-mcp" ]; then
  cp -r "${TMP}/paper-search-mcp" "${SKILLS_DIR}/paper-search-mcp-server"
  echo "  copied paper-search-mcp source — register as MCP server, not as a skill"
fi

# ---- paper-search-usage (fcakyon's thin SKILL.md wrapper) --------------
echo "==> paper-search-usage (fcakyon)"
rm -rf "${TMP}/claude-codex-settings"
git clone --depth 1 https://github.com/fcakyon/claude-codex-settings "${TMP}/claude-codex-settings" || \
  echo "WARN: clone failed"
if [ -d "${TMP}/claude-codex-settings/plugins/paper-search-tools/skills/paper-search-usage" ]; then
  cp -r "${TMP}/claude-codex-settings/plugins/paper-search-tools/skills/paper-search-usage" \
        "${SKILLS_DIR}/"
  echo "  installed paper-search-usage"
fi

# ---- commit-watcher CLAUDE.md template (ships with this pack) ---------
if [ -f "$(dirname "$0")/commit_watcher_CLAUDE.md" ]; then
  echo "==> commit-watcher CLAUDE.md template available"
  echo "  Copy $(dirname "$0")/commit_watcher_CLAUDE.md → your project root"
  echo "  if you want the 'Big Claude is Watching You' commit-history angle."
fi

# ---- symlink so Claude Code finds them --------------------------------
if [ ! -e "${REPO_ROOT}/.claude/skills" ]; then
  mkdir -p "${REPO_ROOT}/.claude"
  ln -s ../.agents/skills "${REPO_ROOT}/.claude/skills"
  echo "==> Symlinked .claude/skills -> .agents/skills"
fi

echo
echo "==> Done. Installed under ${SKILLS_DIR}:"
ls -1 "${SKILLS_DIR}" 2>/dev/null
