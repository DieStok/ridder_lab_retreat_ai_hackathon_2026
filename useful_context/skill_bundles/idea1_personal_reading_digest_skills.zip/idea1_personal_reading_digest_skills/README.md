# `idea1_personal_reading_digest_skills/` — Personal weekly reading digest

For idea **#1**: a personalized weekly reading list built from papers liked
on `#fyi-papers`, a lab-curated author list, or your recent commits ("Big
Claude is Watching You"). Comparable end product: scholar-inbox.com or
Semantic Scholar's research feeds, but lab-tunable.

## Already in the hackathon repo (don't reinstall)

- `paper-lookup` (K-Dense) — arXiv / PubMed / bioRxiv / Semantic Scholar.
- `literature-review` (K-Dense) — full systematic-review pipeline.
- `scientific-writing` (K-Dense).
- `slack-bolt-app` — for delivery to the lab Slack.

This pack adds the **digest-shaped** pieces that aren't covered above.

## Skills in this pack

| # | Skill | Source | Why |
|---|-------|--------|-----|
| 1 | `AI-Briefing-Skill` | `KiKi-Builds/AI-Briefing-Skill` | The closest existing skill to "weekly digest with multi-source fan-in". Sources: RSS, Twitter/X, YouTube, GitHub, arXiv, Reddit, HN. Outputs: newsletter, podcast script, slides, email. Delivery: Slack, Email, Telegram, Notion, RSS. REST API + MCP server. Configurable cron cadence. The architectural backbone for the whole idea. |
| 2 | `paper-search-mcp` | `openags/paper-search-mcp` | Standalone Python MCP for arXiv / PubMed / bioRxiv / Semantic Scholar with PDF download + text extraction. Useful as the "fetch + parse" stage. The repo's existing `paper-lookup` covers similar ground; pick whichever you find easier to wire in. |
| 3 | `paper-search-usage` | `fcakyon/claude-codex-settings` | Thin SKILL.md wrapping `mcp__paper-search__*` tools. Adds IEEE / Scopus / ACM coverage on top of arXiv / PubMed / Semantic Scholar — useful if your reading list needs CS conferences. |
| 4 | `commit-watcher-CLAUDE` (template, in this pack) | n/a | A 30-line CLAUDE.md template that runs `git log --author="${USER}" --since="7 days ago"` weekly, extracts package + topic mentions from the diff, and feeds them as recommendation seeds into the digest pipeline. Implements the brainstorm doc's "Big Claude is Watching You" angle. No public skill exists for this — it's small enough to write yourself. |

## Reference (read, don't install)

- **`arxivdigest`** ([iai-group/arxivdigest](https://github.com/iai-group/arxivdigest), CIKM '20 paper) — the academic prior art for personalized arXiv recommendations with explanation tracking and feedback loops. Read its API design before you reinvent ranking. It's not a Claude skill but it's the architecture to beat.
- **scholar-inbox.com** — commercial, semantic-similarity-based digest. Useful as a UX reference.

## Recommended bundle

Lean stack: `AI-Briefing-Skill` (the digest engine) + `paper-lookup` (already
in repo, do the fetching) + the Slack delivery from `slack-bolt-app` (also in
repo) + `commit-watcher-CLAUDE.md` for the personal-signal angle. Skip
`paper-search-mcp` and `paper-search-usage` unless you need IEEE/Scopus/ACM
coverage that `paper-lookup` doesn't already give you.

## Caveats

- `AI-Briefing-Skill` is feature-rich but Chinese-language-heavy in its docs
  (Feishu, WeChat, Bilibili sources). The pipeline itself is language-agnostic
  — you'll just want to disable the Chinese delivery targets in the config.
- The "based on your commits" angle is privacy-sensitive: if commits go to
  the digest engine, make sure the engine runs on the laptop or HPC, not in
  a cloud LLM.
