# CLAUDE.md — commit-watcher seed for personal digest

Drop this at the root of any project where you want Claude to mine your recent
commits for reading recommendations. It implements the brainstorm doc's "Big
Claude is Watching You" angle: instead of (only) ranking arXiv papers by what
you've previously read, also rank them by what you've actually been *building*.

---

## Job

Once a week (Monday 09:00, say — wire up via cron / GitHub Action / launchd),
Claude should:

1. Run `git log --author="${USER}" --since="7 days ago" --no-merges --stat` in
   the project root.
2. Extract from the diff:
   - imported packages (Python `import X` / `from X import Y`, R `library(X)`,
     Julia `using X`, Rust `use crate::X`)
   - file-name keywords (e.g. `vae_*.py`, `transformer_*.py` → "vae",
     "transformer")
   - PR / commit message nouns (one-pass extraction; ignore boilerplate
     like "fix typo", "bump version")
3. Deduplicate and rank by frequency.
4. Pass the top-10 keywords as the **seed query** to whichever paper-fetch
   layer the project uses (`paper-lookup`, `paper-search-mcp`, or the
   `AI-Briefing-Skill` config).
5. Filter the returned papers against a personal "already seen" cache
   (just a JSON file: `~/.cache/lab-digest/seen.json`).
6. Output a Markdown digest with at most 10 papers, sorted by predicted
   relevance, each with: title, authors, abstract one-sentence summary,
   why-it's-relevant tag (linking back to the keyword that surfaced it),
   PDF URL.

## What NOT to do

- **Do not** send the diff itself to a cloud LLM. Diffs are IP. The keyword
  extraction step runs locally; only the keyword list is passed to the
  paper-search layer.
- **Do not** include private repo names, branch names, or commit SHAs in
  the output. Keywords only.
- **Do not** re-recommend anything in `~/.cache/lab-digest/seen.json`.

## Configuration knobs

Edit `~/.config/lab-digest/config.json`:

```json
{
  "since": "7 days ago",
  "max_papers": 10,
  "min_score": 0.5,
  "sources": ["arxiv", "biorxiv", "pubmed"],
  "extra_keywords": ["bioinformatics", "genomics", "ridder lab"],
  "exclude_keywords": ["typo", "lint", "wip"],
  "delivery": {
    "slack_channel": "#fyi-papers-mybot",
    "format": "markdown"
  }
}
```

`extra_keywords` always seeds the query (lab-wide priors); `exclude_keywords`
filter commit-extracted ones (kill noise like "wip" / "lint").

## Output template

```markdown
# Personal reading digest — {{date}}
Based on your commits to {{repo_list}} this week.
Seed keywords: {{top_10_keywords}}

## 1. {{title}}
{{authors}}, {{venue}}, {{year}} — [PDF]({{pdf_url}})

> {{one_sentence_summary}}

**Why this surfaced:** {{matched_keyword}} (you committed to {{file}} on {{date}}).

---
```

## When asked to "run the digest"

Treat it as a single agent run: read this CLAUDE.md, do the steps in order,
write the output to `digests/{{ISO-week}}.md`, and (if `delivery.slack_channel`
is set and the `slack-bolt-app` skill is available) post a summary +
deep-link to the Slack channel.
