# CLAUDE.md — Journal Club briefing orchestrator

Tells Claude how to chain the JC-enhancement skills into a single briefing
pack delivered to the lab Slack the morning of Journal Club.

---

## Inputs

- The paper PDF (drop in `papers/<jc-date>/paper.pdf`).
- Optionally: the paper's GitHub / Zenodo code repo URL.
- Optionally: a transcript of the JC session itself (idea #2's stack), for
  the *post-hoc* enrichment step.

## Pipeline

### Step 1 — Paper metadata + bibliography

Use `paper-lookup` to pull:
- Title, authors, year, venue
- DOI, arXiv ID, BibTeX
- Bibliography entries with their own DOIs / titles

### Step 2 — Adversarial review (sub-task i)

Run *both* in parallel:
- `lcrawfurd/claude-skills` 6-agent referee (Cunningham's "Referee 2"
  protocol). Output: a structured referee report.
- `academic-research-skills` 7-agent reviewer with the **Devil's Advocate**
  agent. Output: a "what's the strongest case against this paper?" memo.

Write both to `papers/<jc-date>/reviews/`.

### Step 3 — Reproducibility audit (sub-task ii)

If a code repo URL is provided:
- Run `lcrawfurd` 5-parallel reproducibility audit (code audit,
  cross-language replication, directory + replication package, output
  automation, econometrics/statistics).
- Run `claesbackman /review-paper-code` for paper↔code alignment.
- Output: `papers/<jc-date>/reproducibility.md` with: which figures the
  code definitely produces, which it might, which it doesn't, and which
  reported numbers can/can't be regenerated.

If no code repo:
- Skip this step. State explicitly in the briefing pack: "No public code;
  reproducibility cannot be assessed."

### Step 4 — Per-figure code-path traceback (sub-task iii)

If the code repo is in Python / R:
- For each figure in the paper (extracted via `paper-review-helper` or
  `pdftotext`), search the repo for "fig" / "Figure" / `savefig` calls.
- Trace the call chain: which function in which file produces the figure?
  Which inputs feed that function? Which preprocessing steps shape those
  inputs?
- Emit a Mermaid `sequenceDiagram` for the top 3 figures.

### Step 5 — Missing citations (sub-task iv)

Use `literature-review` (already in the lab repo) with:
- Inputs: the paper's abstract + the keywords from its title + the
  research-area noun phrases extracted from the introduction.
- Search arXiv / PubMed / bioRxiv / Semantic Scholar.
- Cross-reference returned papers against the paper's bibliography.
- Flag: highly-cited (>50 citations) papers in the same area NOT cited.
- Don't just dump the list — sort by relevance and explain *why* each
  one might've been worth citing.

### Step 6 — Briefing pack

Write `papers/<jc-date>/briefing.md`:

```markdown
# JC briefing — {{paper title}}
## Authors & venue
{{authors}} · {{venue}} {{year}} · [DOI]({{doi}})

## In one sentence
{{the paper's main claim, paraphrased — not the abstract verbatim}}

## What to read first
- Title + Abstract (2 min)
- Figure 1 + caption (2 min)
- Methods, section {{X}} (5 min) — this is where the key trick is
- Conclusion, paragraph 2 (2 min) — has the limitation discussion

## Adversarial review highlights
**Strongest critique** ({{score}}/10 from Devil's Advocate):
> {{quote from the DA agent's memo}}

**Specific issues to ask about in JC:**
1. {{issue with a verbatim quote from the paper for context}}
2. {{...}}
3. {{...}}

## Reproducibility status
- Public code: {{yes/no/partial}} ({{repo URL}})
- Public data: {{yes/no/partial}}
- Figures regeneratable: {{N of M}}
- Reported numbers regeneratable: {{N of M}}
- Notable gaps: {{...}}

## Per-figure code paths (top 3)
### Figure 1
```mermaid
sequenceDiagram
  ...
```

## Possibly missing citations
{{Top 5, sorted by relevance, with one-sentence rationale each}}

## Suggested discussion questions
1. {{...}}
2. {{...}}
3. {{...}}

## Materials in this briefing pack
- `paper.pdf`
- `reviews/referee-report.md`
- `reviews/devils-advocate.md`
- `reproducibility.md`
- `figures-code-paths.md`
- `missing-citations.md`
```

### Step 7 — Slack delivery

Post to the JC channel with `slack-bolt-app`:

```
📰 *JC briefing — <paper title>*
TL;DR: <one sentence>
🎯 *3 key questions for tomorrow:*
1. ...
2. ...
3. ...
📂 Full briefing: <link to briefing.md>
🧪 Reproducibility: <traffic-light status>
📚 5 missing citations to mention: <thread reply>
```

## Stretch goal: live JC enrichment

(Skip this for the 50-min hackathon. Listed for completeness.)

If a transcription of the JC session itself is captured (idea #2 stack):
- After the session, re-run the missing-citations step using the
  transcript's actual discussion topics as additional keywords.
- Add a "🔁 follow-up" Slack post: "topics raised in the session that
  weren't in the briefing."
- If the discussion called out a method the paper *didn't* use, generate
  a Marimo notebook (idea #8 stack) that loads the paper's code +
  swaps in the alternative method, so the next JC can see the result.
  This is a multi-team effort, not a single-team build.

## Don't

- Don't trust the LLM's "missing citations" list verbatim. Always check
  that the paper genuinely doesn't cite them — agents hallucinate
  bibliographies. The post-process should grep the actual bib file.
- Don't post the full Devil's Advocate memo to the JC channel. Quote
  the strongest single point and link to the full memo. The memo is
  100% adversarial and reads as harsh out of context.
- Don't run the reproducibility audit on a private repo without
  permission. If the paper's code is "available on request", the JC
  briefing should say so, not attempt to scrape it.
- Don't auto-post the briefing to a public channel without a human
  glance. JC papers can be from collaborators or competitors; tone
  matters.
