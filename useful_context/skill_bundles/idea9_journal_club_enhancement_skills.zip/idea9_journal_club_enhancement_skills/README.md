# `idea9_journal_club_enhancement_skills/` — Journal Club enhancement

For idea **#9**: for each Journal Club paper, run agent-based pipelines that
do (i) adversarial review, (ii) code-vs-methods reproducibility audit,
(iii) per-figure code-path diagrams, (iv) "missing citations" detection.
The brainstorm doc's stretch goal is interactive notebooks that recapitulate
paper figures and let the JC ask "what if the authors had used method X
instead?" on demand.

## Already in the hackathon repo (don't reinstall)

- `paper-lookup` (K-Dense) — lookup the paper + its references.
- `literature-review` (K-Dense) — for "what should this paper have cited?"
- `scientific-writing` (K-Dense) — review document formatting.
- `compound-engineering` — `ce-frontend-design` for the figure-walkthrough
  HTML, plus the various review skills.

## Skills in this pack

| # | Skill | Source | Why |
|---|-------|--------|-----|
| 1 | `claude-skills` (lcrawfurd) | `lcrawfurd/claude-skills` | The most paper-shaped review pack: 5-framework paper review (Edmans / Nyhan / Humphreys / Blattman + a fifth), a **6-agent referee** implementing Cunningham's MixtapeTools "Referee 2" protocol, **and a computational reproducibility audit** with 5 parallel sub-audits. Aimed at economists; the frameworks transfer cleanly to bioinformatics. |
| 2 | `AI-research-feedback` (claesbackman) | `claesbackman/AI-research-feedback` | (Already listed in idea #4.) For idea #9, the relevant slash commands are `/review-paper` (6-agent parallel review) and `/review-paper-code` (paper-vs-code alignment). Curl-installed as commands. |
| 3 | `academic-research-skills` (Imbad0202) | `Imbad0202/academic-research-skills` | A 10-stage research pipeline (RESEARCH → WRITE → REVIEW → REVISE → FINALIZE) with a 7-agent reviewer including a **Devil's Advocate Reviewer** as the 7th agent, plus a re-review verification mode and Socratic revision coaching. The Devil's-Advocate angle is exactly the "adversarial review of findings" the brainstorm doc names. |
| 4 | `paper-review-helper` | mcpmarket | PDF → LaTeX conversion (Mathpix), figure extraction, **SymPy math verification** for equations, automated citation checking. The math-verification step is the most differentiated feature here — useful when the JC paper has equations the audience hasn't dug into yet. |
| 5 | `paper-reviewer` (astoreyai) | `astoreyai/claude-skills` | Pre-submission orchestration with statistical validation, bias detection, compliance checks, citation integrity, reproducibility for data + code availability. Useful as the "what would a real reviewer flag?" mode. |
| 6 | `meeting-insights-analyzer` | `ComposioHQ/awesome-claude-skills` | (Already listed in ideas #2 and #5.) For idea #9, the brainstorm doc's stretch goal — "LLM listens in on the Journal Club and tweaks visualizations on the fly" — needs a transcription + analysis loop. This skill handles the cross-meeting analysis layer. |
| 7 | `journal_club_orchestrator_CLAUDE.md` (template, in this pack) | n/a | A CLAUDE.md template that chains: (1) `paper-lookup` to fetch the paper + supplementary, (2) `lcrawfurd` 6-agent referee + reproducibility audit, (3) `academic-research-skills` Devil's-Advocate pass, (4) `literature-review` for missing-citations check, (5) per-figure code-path traceback if the repo is available, (6) emit a JC briefing pack. |

## Recommended bundle

Lean: `lcrawfurd/claude-skills` (the 6-agent referee + reproducibility
audit — these two together cover most of idea #9 sub-tasks i–ii) + the
`journal_club_orchestrator_CLAUDE.md` template + the existing
`paper-lookup` and `literature-review` from the repo. Add
`academic-research-skills` if you want the explicit Devil's Advocate
reviewer; add `paper-review-helper` if the JC paper has hairy
equations that benefit from SymPy verification.

## Caveats

- Most of these skills assume the paper is a *PDF* with text. Scanned PDFs
  or paper-only-on-arXiv-without-source-LaTeX make the math-verification
  / structure-extraction steps fragile. Pre-process with Mathpix or run
  `pdftotext` first.
- The "missing citations" angle is a search problem: feed the paper's
  abstract + topic keywords to `literature-review` and look for highly-cited
  papers that the bibliography *doesn't* contain. Don't expect it to find
  every gap, but it will reliably find the obvious ones (canonical
  textbooks, major prior methods).
- The brainstorm doc's stretch goal — *the LLM listens in to the JC and
  generates interactive figures on the fly* — needs ideas #2 (transcription)
  + #8 (interactive demos via Marimo) wired together. That's a multi-team
  combo, not a 50-minute single-team build.
- For sub-task (iii) "per-figure code-path diagrams": this is feasible on
  papers with public code on GitHub. Walk the code (Claude can do
  `Read` + `Grep`), trace which functions feed each figure, and emit a
  Mermaid sequence diagram. For papers without code, skip this sub-task
  and say so explicitly in the briefing.
