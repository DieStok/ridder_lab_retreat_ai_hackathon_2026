#!/usr/bin/env bash
# install.sh — skill pack for hackathon idea #9 (Journal Club enhancement).
set -euo pipefail
REPO_ROOT="$(pwd)"
SKILLS_DIR="${REPO_ROOT}/.agents/skills"
TMP="${TMPDIR:-/tmp}/idea9-install"
mkdir -p "${SKILLS_DIR}" "${TMP}"
echo "==> Installing into ${SKILLS_DIR}"

# ---- lcrawfurd/claude-skills (6-agent referee + reproducibility audit) -
echo "==> lcrawfurd/claude-skills (the heart of this idea)"
rm -rf "${TMP}/lcrawfurd"
git clone --depth 1 https://github.com/lcrawfurd/claude-skills "${TMP}/lcrawfurd" || \
  echo "WARN: clone failed"
if [ -d "${TMP}/lcrawfurd" ]; then
  cp -r "${TMP}/lcrawfurd" "${SKILLS_DIR}/lcrawfurd-claude-skills"
  echo "  installed lcrawfurd-claude-skills"
fi

# ---- claesbackman review-paper + review-paper-code (slash commands) ---
echo "==> claesbackman/AI-research-feedback (slash commands)"
COMMANDS_DIR="${HOME}/.claude/commands"
mkdir -p "${COMMANDS_DIR}"
for cmd in review-paper review-paper-light review-paper-code; do
  curl -fsSL "https://raw.githubusercontent.com/claesbackman/AI-research-feedback/main/Skills/${cmd}.md" \
    -o "${COMMANDS_DIR}/${cmd}.md" 2>/dev/null && \
    echo "  installed /${cmd}" || \
    echo "  WARN: ${cmd} curl failed"
done

# ---- Imbad0202/academic-research-skills (with Devil's Advocate) -------
echo "==> Imbad0202/academic-research-skills"
rm -rf "${TMP}/academic-research-skills"
git clone --depth 1 https://github.com/Imbad0202/academic-research-skills "${TMP}/academic-research-skills" || \
  echo "WARN: clone failed"
if [ -d "${TMP}/academic-research-skills" ]; then
  cp -r "${TMP}/academic-research-skills" "${SKILLS_DIR}/academic-research-skills"
  echo "  installed academic-research-skills"
fi

# ---- mcpmarket Paper Review Helper (manual fetch) ---------------------
echo "==> Paper Review Helper (mcpmarket — manual fetch)"
echo "  Fetch SKILL.md from https://mcpmarket.com/tools/skills/paper-review-helper"
echo "  Put in ${SKILLS_DIR}/paper-review-helper/SKILL.md"
echo "  Note: requires Mathpix API key for PDF-to-LaTeX (paid service)."

# ---- astoreyai paper-reviewer ----------------------------------------
echo "==> astoreyai/claude-skills (paper-reviewer)"
if command -v npx >/dev/null 2>&1; then
  npx --yes skillfish add astoreyai/claude-skills paper-reviewer 2>/dev/null || \
    echo "  WARN: skillfish not available; clone https://github.com/astoreyai/claude-skills manually"
else
  echo "  WARN: npx not found"
fi

# ---- meeting-insights-analyzer (ComposioHQ) - if not already installed
if [ ! -d "${SKILLS_DIR}/meeting-insights-analyzer" ]; then
  rm -rf "${TMP}/awesome-claude-skills"
  git clone --depth 1 https://github.com/ComposioHQ/awesome-claude-skills "${TMP}/awesome-claude-skills" || \
    echo "WARN: clone failed"
  if [ -d "${TMP}/awesome-claude-skills/meeting-insights-analyzer" ]; then
    cp -r "${TMP}/awesome-claude-skills/meeting-insights-analyzer" "${SKILLS_DIR}/"
    echo "  installed meeting-insights-analyzer"
  fi
fi

# ---- Journal Club orchestrator CLAUDE.md -----------------------------
if [ -f "$(dirname "$0")/journal_club_orchestrator_CLAUDE.md" ]; then
  echo "==> journal_club_orchestrator_CLAUDE.md available"
  echo "  Copy → your project root for the orchestrator template."
fi

# ---- symlink ----------------------------------------------------------
if [ ! -e "${REPO_ROOT}/.claude/skills" ]; then
  mkdir -p "${REPO_ROOT}/.claude"
  ln -s ../.agents/skills "${REPO_ROOT}/.claude/skills"
  echo "==> Symlinked .claude/skills -> .agents/skills"
fi

echo
echo "==> Done. Installed under ${SKILLS_DIR}:"
ls -1 "${SKILLS_DIR}" 2>/dev/null
echo
echo "==> Slash commands at ${COMMANDS_DIR}:"
ls -1 "${COMMANDS_DIR}" 2>/dev/null | grep -E "^review-" || true
